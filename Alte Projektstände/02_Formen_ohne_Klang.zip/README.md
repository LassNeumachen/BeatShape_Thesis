# BeatShape 0.2

*Hinweis: Das Programm enthält Bugs und kann crashen.*

## Projekt starten

Abhängigkeiten installieren:

```bash
npm install
```

starten:

```bash
npm run dev
```

Im Terminal angezeigte Adresse im Browser öffnen.

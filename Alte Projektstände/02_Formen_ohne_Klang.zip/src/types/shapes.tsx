export type ShapeType = 'polygon' | 'circle' | 'custom'

export type BeatShapeBase = {
    id: string;
    // shape: paper.Path;
    // marker: paper.Path;
    type: ShapeType;
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    loopDuration: number;
    triggerOffsets?: number[];
    rotation: number;
};

export type PolygonBS = BeatShapeBase & {
    type: 'polygon';
    size: number;
    corners: number;
}

export type CircleBS = BeatShapeBase & {
    type: 'circle';
    radius: number;
}

export type CustomBS = BeatShapeBase & {
    type: 'custom';
    cornerPoints?: [number, number][];
}

export type BeatShape = PolygonBS | CircleBS | CustomBS;
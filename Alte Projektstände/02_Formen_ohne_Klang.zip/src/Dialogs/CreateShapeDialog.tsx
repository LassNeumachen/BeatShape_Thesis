import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
    Grid,
    type ShapeOptions
} from '@mui/material';
import {useEffect, useRef, useState} from "react";
import paper from 'paper'
import HorizontalSpacingToggleButton from "../components/HorizontalSpacingtoggleButton";
import type {CreateShapeInput} from "../lib/shapeFactory";
import type {BeatShape, ShapeType} from "../types/shapes";
import SquareDump from "../assets/SquareDump2.png"
import {ShapeCard, type ShapeCardProps} from "../components/ShapeCard";
import VolumeSlider from "../components/VolumeSlider";
import Slider from "@mui/material/Slider";


type CreateShapeDialogProps = {
    open: boolean;
    x: number;
    y: number;
    onClose: () => void;
    onCreateShape: (input: CreateShapeInput) => void;
};

type shapeData = {
    shapeType: 'circle' | 'rectangle' | 'polygon';
    position: { x: number; y: number };
    size: number,
    volume: number,
    fillColor: string,
    offset: number,
    rotation?: number,
    note: string,
}

export type ShapeKey = {
    type: ShapeType,
    corners: number,
}

const shapeOptions: ShapeKey[] = [
    { type: 'circle', corners: 4 },
    { type: 'polygon', corners: 3 },
    { type: 'polygon', corners: 4 },
    { type: 'polygon', corners: 5 },
    { type: 'polygon', corners: 6 },
    { type: 'polygon', corners: 7 },
    { type: 'polygon', corners: 8 },
    { type: 'polygon', corners: 8 },
    { type: 'polygon', corners: 12 },
    { type: 'polygon', corners: 16 },
];

export default function CreateShapeDialog({ open, x, y, onClose, onCreateShape }: CreateShapeDialogProps) {
    const [selectedShape, setSelectedShape] = useState<ShapeKey>({corners: 4,type: 'polygon'})
    const [sound, setSound] = useState('baseDrum')
    const [volume, setVolume] = useState(40)
    const [rotation, setRotation] = useState(0)
    const previewCanvas = useRef<HTMLCanvasElement | null>(null);
    const [color, setColor] = useState<string>('#2563eb');
    const colors = ['#2563eb', '#ef4444', '#10b981', '#f59e0b', '#111827'];

    const handleCreate = () => {
        const input: CreateShapeInput = {
            type: selectedShape.type,
            x,
            y,
            fillColor: color,
            ballColor: 'white',
            offset: 0,
            lastOffset: 0,
            size: volume,
            corners: selectedShape.corners,
                rotation: rotation
        };
        console.log(input)
        onCreateShape(input);
    };

    function setActiveShape(key: ShapeKey) {
        setSelectedShape(key)
    }

    function onSetRotation(value: number) {
        setRotation(value)
    }

    useEffect(() => {
        if(!open || !previewCanvas.current) return;

        const scope = new paper.PaperScope();
        scope.setup(previewCanvas.current);
        scope.project.clear();

        const input: CreateShapeInput = {
            type: selectedShape.type,
            x: 100,
            y: 100,
            fillColor: color,
            ballColor: 'white',
            offset: 0,
            lastOffset: 0,
            size: volume,
            corners: selectedShape.corners,
            rotation: rotation
        };

        const center = new scope.Point(previewCanvas.current.width/2,previewCanvas.current.height/2)
        let path :paper.Path;
        if (input.type === 'polygon') {
            path = new scope.Path.RegularPolygon({
                center,
                sides: input.corners,
                radius: input.size + 30,
                fillColor: color,
            });
            if(input.rotation !== undefined) {
                path.rotation = input.rotation
            }
        } else if (input.type === 'circle') {
            path = new scope.Path.Circle({
                center,
                radius: input.radius,
                fillColor: color,
            });
        } else if (input.type === 'custom') {
            path = new scope.Path({
                segments: [
                    [35, 85],
                    [60, 30],
                    [90, 75],
                ],
                closed: true,
                fillColor: color,
            });
        }
        if(input.rotation !== undefined) {
            path.rotation = input.rotation
        }

    }, [open, selectedShape, volume, rotation, color])

    return (
        <Dialog open={open} onClose={onClose}>
            <DialogTitle>Shape erstellen</DialogTitle>
            <DialogContent>
                <Typography>
                    Position: {x}, {y}
                </Typography>
                <Typography>
                    Active Shape: {selectedShape.type} {selectedShape.corners}
                </Typography>

                <Grid container={true}>
                    <Grid size={7} sx={{padding: 1}}>
                        <Box sx={{display: 'flex', flexDirection: 'column', alignItems: 'center', backgroundColor: 'lightgray'}}>
                            <canvas ref={previewCanvas} height={300} width={300}></canvas>
                        </Box>
                    </Grid>
                    <Grid size={5} sx={{padding: 1}}>
                        <Grid container spacing={2}>
                            {shapeOptions.map((shape) => {
                                return (
                                    <ShapeCard
                                        color={color}
                                        key={`${shape.type}-${shape.corners}`}
                                        shape={{ type: shape.type, corners: shape.corners }}
                                        activeShape={selectedShape}
                                        setActiveShape={setActiveShape}
                                    />
                                );
                            })}
                        </Grid>
                    </Grid>
                </Grid>

                <Box sx={{ display: 'flex', gap: 1 }}>
                    {colors.map((colorOption) => (
                        <Box
                            key={colorOption}
                            onClick={() => setColor(colorOption)}
                            sx={{
                                width: 28,
                                height: 28,
                                borderRadius: '50%',
                                backgroundColor: colorOption,
                                cursor: 'pointer',
                                border: color === colorOption ? '2px solid black' : '2px solid transparent',
                            }}
                        />
                    ))}
                </Box>
                {/*<VolumeSlider onChange={onSetVolume}></VolumeSlider>*/}
                <Typography>Size/Volume</Typography>
                <Slider
                    aria-label="Volume/Size"
                    value={volume}
                    onChange={(_,value) => setVolume(value)}
                    valueLabelDisplay="auto"
                    sx={{
                        width: 300,
                        color: 'success.main',
                        '& .MuiSlider-thumb': {
                            borderRadius: '1px',
                        },
                    }}
                >
                </Slider>
                <Typography>Rotation/Offset</Typography>
                <Slider
                    value={rotation}
                    onChange={(_, value) => onSetRotation(value as number)}
                    // aria-label="Temperature"
                    defaultValue={0}
                    valueLabelDisplay="auto"
                    // shiftStep={30}
                    // step={30}
                    // marks
                    min={-180}
                    max={180}
                    sx={{
                        width: 300,
                        color: 'success.main',
                        '& .MuiSlider-thumb': {
                            borderRadius: '1px',
                        },
                    }}
                />
            </DialogContent>
            <DialogActions>
                <Button sx={{backgroundColor: 'lightblue'}} onClick={() => {
                    handleCreate();
                    onClose();
                }
                }>Erstellen</Button>
                <Button sx={{backgroundColor: 'red'}} onClick={onClose}>Schließen</Button>
            </DialogActions>
        </Dialog>
    );
}

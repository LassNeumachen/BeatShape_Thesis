import type { BeatShape, ShapeType } from '../types/shapes';

// export function createShape(x: number, y: number, size: number = 40, color: string = 'blue', shapeType: ShapeType, corners: number[] | number){
//     let shape: paper.Path = new paper.Path.Rectangle({
//         point: [200, 400],
//         size: [200, 200],
//         fillColor: 'pink'
//     })
//     if(shapeType === 'polygon'){
//         shape = new paper.Path.RegularPolygon({
//             center: [x, y],
//             sides: corners,
//             radius: size,
//             fillColor: color,
//         })
//     }
//     else if(shapeType === 'circle'){
//         shape = new paper.Path.Circle({
//             center: [x, y],
//             radius: size,
//             fillColor: color,
//         })
//     }
//     else if(shapeType === 'custom') {
//         shape = new paper.Path({
//             segments: corners,
//             closed: true,
//             fillColor: color,
//         })
//     }
//     return createBeatShape(shape,shapeType,x,y,size, color)
// }
export type CreateShapeInput =
    | {
    type: 'polygon';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    size: number;
    corners: number;
    rotation: number;
}
    | {
    type: 'circle';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    radius: number;
    rotation: number;
}
    | {
    type: 'custom';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    cornerPoints: [number, number][];
    rotation: number;
};

export function createShape(input: CreateShapeInput): BeatShape {
    const base = {
        id: crypto.randomUUID(),
        type: input.type,
        x: input.x,
        y: input.y,
        fillColor: input.fillColor,
        ballColor: input.ballColor,
        offset: input.offset,
        lastOffset: input.lastOffset,
        loopDuration: 2,
        rotation: input.rotation,
        ...(input.triggerOffsets !== undefined
            ? { triggerOffsets: input.triggerOffsets }
            : {}),
    };

    if (input.type === 'polygon') {
        return {
            ...base,
            type: 'polygon',
            size: input.size,
            corners: input.corners,
        };
    }

    if (input.type === 'circle') {
        return {
            ...base,
            type: 'circle',
            radius: input.radius,
        };
    }

    return {
        ...base,
        type: 'custom',
        cornerPoints: input.cornerPoints,
    };
}




// function createBeatShape(
//     shape: paper.Path,
//     type: ShapeType,
//     x: number,
//     y: number,
//     size: number,
//     color: string,
//     triggerOffsets?: number,
//     startDivision: number = 1,
//     markerColor: string = 'white'
// ): BeatShape {
//     shape.rotate(360 / startDivision);
//
//     const marker = new paper.Path.Circle({
//         center: shape.getPointAt(0),
//         radius: 8,
//         fillColor: markerColor,
//     });
//
//     marker.rotate(360 / startDivision);
//
//     return {
//         id: crypto.randomUUID(),
//         shape,
//         marker,
//         type,
//         x,
//         y,
//         size,
//         fillColor: color,
//         ballColor: markerColor,
//         offset: shape.length / startDivision,
//         lastOffset: shape.length / startDivision,
//         triggerOffsets:
//             triggerOffsets === undefined
//                 ? getCornerOffsets(shape)
//                 : [triggerOffsets + shape.length / startDivision],
//         baseMarkerColor: markerColor,
//     };
// }

// function getCornerOffsets(shape:paper.Path) {
//     const offsets = [];
//     for (let i = 0; i < shape.segments.length; i++) {
//         offsets.push(shape.getOffsetOf(shape.segments[i]!.point));
//     }
//     return offsets;
// }
import {type BoxProps, colors, Paper} from "@mui/material";
import {useEffect, useRef} from 'react';
import paper from 'paper';
import type { ShapeType } from '../types/shapes';
import {AbcTwoTone} from "@mui/icons-material";
import ToggleButton from "@mui/material/ToggleButton";
import type {ShapeKey} from "../Dialogs/CreateShapeDialog";

export type ShapeCardProps = {
    color: string;
    shape: ShapeKey;
    activeShape: ShapeKey
    setActiveShape: (key: ShapeKey) => void;
}

export function ShapeCard(props: ShapeCardProps) {
    const shapeCanvas = useRef<HTMLCanvasElement | null>(null);

    const isSelected =
        props.shape.type === props.activeShape.type &&
        props.shape.corners === props.activeShape.corners;

    useEffect(() => {
        if (!shapeCanvas.current) return;
        const scope = new paper.PaperScope();
        scope.setup(shapeCanvas.current);
        scope.project.clear();

        const center = new scope.Point(shapeCanvas.current.width/2, shapeCanvas.current.height/2);

        if (props.shape.type === 'polygon') {
            new scope.Path.RegularPolygon({
                center,
                sides: props.shape.corners,
                radius: 28,
                fillColor: props.color,
            });
        } else if (props.shape.type === 'circle') {
            new scope.Path.Circle({
                center,
                radius: 28,
                fillColor: props.color,
            });
        } else if (props.shape.type === 'custom') {
            new scope.Path({
                segments: [
                    [35, 85],
                    [60, 30],
                    [90, 75],
                ],
                closed: true,
                fillColor: props.color,
            });
        }

        return () => {
            scope.project.clear();
        };

    }, [props.shape.type, props.shape.corners, props.color]);

    return (
        <ToggleButton
            value={`${props.shape.type}-${props.shape.corners}`}
            selected={isSelected}
            onChange={() => props.setActiveShape(props.shape)}
        >
            <canvas ref={shapeCanvas} data-role="shapeCard" width={70} height={70} />
        </ToggleButton>
    );
}
{/*// <Paper sx={{display: 'flex', flexDirection: 'column', alignItems: 'start'}} elevation={3} onClick={() => props.setActiveShape(`${props.type}-${props.corners}`)}>*/}
{/*//     <canvas ref={canvasRef} width={80} height={80}>*/}
{/*//*/}
{/*//     </canvas>*/}
{/*// </Paper>*/}
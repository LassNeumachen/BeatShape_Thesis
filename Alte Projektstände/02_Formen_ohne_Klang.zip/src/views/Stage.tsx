import {Box, Button, Typography} from '@mui/material';
import { useEffect, useRef, useState } from 'react';
import CreateShapeDialog from '../Dialogs/CreateShapeDialog';
import { type BeatShape } from '../types/shapes';
import { createShape, type CreateShapeInput } from '../lib/shapeFactory';
import paper from 'paper';

type StageProps = {
    onStageClick?: (x: number, y: number) => void;
};

type RuntimeShape = {
    id: string;
    path: paper.Path;
    marker: paper.Path.Circle;
    offset: number;
    loopDuration: number;
};



export default function Stage({ onStageClick }: StageProps) {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const paperScopeRef = useRef<paper.PaperScope | null>(null);

    const [coordinates, setCoordinates] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [mousePosition, setMousePosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [manageDialog, setManageDialog] = useState(false);
    const [shapes, setShapes] = useState<BeatShape[]>([]);
    const runtimeShapesRef = useRef<RuntimeShape[]>([]);

    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        scope.project.clear();

        const runtimeShapes = shapes.map((shape) => {
            let path: paper.Path;

            if (shape.type === 'polygon') {
                path = new scope.Path.RegularPolygon({
                    center: new scope.Point(shape.x, shape.y),
                    sides: shape.corners,
                    radius: shape.size,
                    fillColor: shape.fillColor,
                });
            } else if (shape.type === 'circle') {
                path = new scope.Path.Circle({
                    center: new scope.Point(shape.x, shape.y),
                    radius: shape.radius,
                    fillColor: shape.fillColor,
                });
            } else {
                path = new scope.Path({
                    segments: shape.cornerPoints,
                    closed: true,
                    fillColor: shape.fillColor,
                });
            }
            if(shape.rotation !== undefined) {
                path.rotate(shape.rotation)
            }

            const marker = new scope.Path.Circle({
                center: path.getPointAt(shape.offset) ?? path.position,
                radius: 10,
                fillColor: 'white',
            });

            return {
                id: shape.id,
                path,
                marker,
                offset: shape.offset,
                loopDuration: shape.loopDuration,
            };
        });

        runtimeShapesRef.current = runtimeShapes;
    }, [shapes]);




    useEffect(() => {
        if (!canvasRef.current) return;

        const scope = new paper.PaperScope();
        scope.setup(canvasRef.current);
        paperScopeRef.current = scope;

        return () => {
            scope.project.clear();
        };
    }, []);


    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        scope.view.onFrame = (event: { delta: number }) => {
            for (const runtime of runtimeShapesRef.current) {
                const speed = runtime.path.length / runtime.loopDuration;
                runtime.offset = (runtime.offset + speed * event.delta) % runtime.path.length;

                runtime.marker.position =
                    runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;
            }
        };

        return () => {
            scope.view.onFrame = null;
        };
    }, []);


    function handleClick(event: React.MouseEvent<HTMLDivElement>) {
        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() !== 'canvas' || target.id !== 'MainCanvas') {
            return;
        }

        const x = event.clientX;
        const y = event.clientY;

        onStageClick?.(x, y);

        setCoordinates({ x, y });
        setManageDialog(true);
    }

    function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
        setMousePosition({
            x: event.clientX,
            y: event.clientY,
        });
    }

    function handleCloseDialog() {
        setManageDialog(false);
    }

    return (
        <Box
            onClick={handleClick}
            onMouseMove={handleMouseMove}
            sx={{
                width: '100vw',
                height: '100vh',
                backgroundColor: 'grey',
                position: 'relative',
                overflow: 'hidden',
                cursor: 'none',
            }}
        >
            <Button onClick={() => console.log(shapes)}>1234</Button>
            <canvas
                ref={canvasRef}
                id={"MainCanvas"}
                width={window.innerWidth}
                height={window.innerHeight}
                style={{ width: '100%', height: '100%', display: 'block' }}
            />

            <Box
                sx={{
                    position: 'fixed',
                    left: manageDialog ? coordinates.x : mousePosition.x,
                    top: manageDialog ? coordinates.y : mousePosition.y,
                    transform: 'translate(-50%, -50%)',
                    width: 44,
                    height: 44,
                    borderRadius: '50%',
                    backgroundColor: 'rgba(255,255,255,0.2)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    pointerEvents: 'none',
                    zIndex: 20,
                }}
            >
                <Box
                    component="span"
                    sx={{
                        fontSize: 24,
                        lineHeight: 1,
                        display: 'block',
                        transform: 'translateY(2px)',
                    }}
                >
                    +
                </Box>
            </Box>

            {!manageDialog && (
                <Box
                    sx={{
                        position: 'fixed',
                        left: mousePosition.x + 30,
                        top: mousePosition.y,
                        transform: 'translateY(-50%)',
                        pointerEvents: 'none',
                        zIndex: 20,
                    }}
                >
                    <Typography sx={{ fontSize: 14 }}>
                        Shape platzieren
                    </Typography>
                </Box>
            )}

            <CreateShapeDialog
                open={manageDialog}
                onClose={handleCloseDialog}
                onCreateShape={(input: CreateShapeInput) =>
                    setShapes((prev) => [...prev, createShape(input)])
                }
                x={coordinates.x}
                y={coordinates.y}
            />
        </Box>
    );
}

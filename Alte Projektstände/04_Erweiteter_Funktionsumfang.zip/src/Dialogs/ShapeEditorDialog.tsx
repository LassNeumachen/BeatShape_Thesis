import {Box, Button, Dialog, DialogTitle, Grid, LinearProgress, Typography} from "@mui/material";
import {useState} from "react";
import ToggleButton from "@mui/material/ToggleButton";
import { formatBeatValue } from "../lib/helper/beatValueFormatter";

import ganzeNote from "../assets/Notes/Noten_Ganze_Note.svg"
import halbeNote from "../assets/Notes/Noten_Halbe_Note.svg"
import viertelNote from "../assets/Notes/Noten_Viertel_Note.svg"
import achtelNote from "../assets/Notes/Noten_Achtel_Note.svg"
import sechzehntelNote from "../assets/Notes/Noten_Sechzehntel_Note.svg"
import zweiunddreissigstelNote from "../assets/Notes/Noten_Zweiunddreißigstel_Note.svg"
import BeatlineWithNotes from "../components/BeatlineWithNotes";
import {appColors} from "../theme";

export type ShapeEditorProps = {
    open: boolean;
    onClose: () => void;
    createCustomShape: (beatValues: number[]) => void;
}

const values: number[] = [1, 1 / 2, 1 / 4, 1 / 8, 1 / 16, 1 / 32]

export default function ShapeEditorDialog(props: ShapeEditorProps) {

    const [beatValue, setBeatValue] = useState(0);
    const [beatValues, setBeatValues] = useState<number[]>([]);
    const [dotted, setDotted] = useState(false);
    const [doubleDotted, setDoubleDotted] = useState(false);

    function getBeatValueImage(value: number) {
        switch (value) {
            case 1:
                return ganzeNote;

            case 1 / 2:
                return halbeNote;

            case 1 / 4:
                return viertelNote;

            case 1 / 8:
                return achtelNote;

            case 1 / 16:
                return sechzehntelNote;

            case 1 / 32:
                return zweiunddreissigstelNote;

            default:
                return "";
        }
    }

    function addBeatValue(value: number) {
        if (dotted) {
            value += value / 2
            setDotted(false);
        }

        if (doubleDotted) {
            value += value / 2 + value / 4;
            setDoubleDotted(false)
        }

        setBeatValue(beatValue + value);
        setBeatValues((prev) => [...prev, value]);
    }

    function manageDotting(singelDotting: boolean) {
        if (singelDotting) {
            setDotted(!dotted);
            setDoubleDotted(false);
        } else {
            setDoubleDotted(!doubleDotted);
            setDotted(false);
        }
    }

    function reset() {
        setBeatValue(0);
        setBeatValues([]);
        setDotted(false);
        setDoubleDotted(false)
    }

    return (
        <Dialog
            open={props.open}
            onClose={(event, reason) => {
                if (reason === "backdropClick") {
                    reset();
                    props.onClose();
                }
            }}
        >
            <DialogTitle>
                Create new Beatshape
            </DialogTitle>

            {/*OVERVIEW*/}

            <Box sx={{ p:3 }}>
                <BeatlineWithNotes beatValues={beatValues} height={130} showProgress={true}></BeatlineWithNotes>

                <Typography>
                    {formatBeatValue(beatValue)}
                </Typography>

                <LinearProgress
                    variant="determinate"
                    value={beatValue * 100}
                />

                <Typography variant="body2" color="textSecondary">
                    Taktwert
                </Typography>
            </Box>

            <Box sx={{ p: 3 }}>



                <Grid container spacing={2} sx={{ mt: 2 }}>

                    {values.map((value) => {

                        return (
                            <Button
                                key={value}

                                sx={{
                                    minWidth: 80,
                                    minHeight: 80,
                                    border: "1px solid lightgray"
                                }}

                                disabled={
                                    dotted
                                        ? beatValue + value + value / 2 > 1
                                        : doubleDotted
                                            ? beatValue + value + value / 2 + value / 4 > 1
                                            : beatValue + value > 1
                                }

                                onClick={() => addBeatValue(value)}
                            >

                                <Box
                                    component="img"
                                    src={getBeatValueImage(value)}
                                    alt={formatBeatValue(value)}
                                    sx={{
                                        width: 40,
                                        height: 40,
                                        objectFit: "contain"
                                    }}
                                />

                            </Button>
                        );
                    })}

                </Grid>

                <Box sx={{ mt: 2, display: "flex", gap: 2 }}>

                    <ToggleButton
                        sx={{
                            backgroundColor: dotted ? 'green' : 'white'
                        }}
                        value={dotted}
                        onClick={() => manageDotting(true)}
                    >
                        .
                    </ToggleButton>

                    <ToggleButton
                        sx={{
                            backgroundColor: doubleDotted ? 'green' : 'white'
                        }}
                        value={doubleDotted}
                        onClick={() => manageDotting(false)}
                    >
                        ..
                    </ToggleButton>

                </Box>

                <Box sx={{ mt: 3, display: "flex", gap: 2 }}>

                    <Button onClick={() => reset()}>
                        Reset
                    </Button>

                    <Button
                        disabled={beatValue !== 1}
                        onClick={() => {
                            props.createCustomShape(beatValues);
                            reset()
                        }}
                    >
                        Create
                    </Button>

                    <Button
                        onClick={() => {
                            props.onClose();
                            reset()
                        }}
                    >
                        Close
                    </Button>

                </Box>

            </Box>

        </Dialog>
    )
}

import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
    Grid,
} from '@mui/material';
import {useCallback, useEffect, useRef, useState} from "react";
import paper from 'paper'
import type {CreateShapeInput} from "../lib/shapeFactory";
import {ShapeCard} from "../components/ShapeCard";
import {type Sound, type SoundType, soundTypes} from "../types/sounds";
import {SoundComponent} from "../components/SoundComponent";
import {playSound, startAudio} from "../lib/audioEngine";
import {checkTriggerCrossing} from "../lib/helper/TriggerHelper";
import {calculateShapePoints} from "../lib/helper/shapeCalculator";
import ShapeEditorDialog from "./ShapeEditorDialog";
import type {BeatShape, CustomPathData} from "../types/shapes";
import {buildPaperPath, transformPathData} from "../lib/helper/paperPath";
import SliderComponent from "../components/SliderComponent";
import { appColors } from "../theme";
import BeatlineWithNotes from "../components/BeatlineWithNotes";
import StartStopButton from "../components/Buttons/StopPlayButtonComponent";
import BuildNewBeatshapeButton from "../components/Buttons/BuildNewBeatshapeButton";
import {alpha} from "@mui/material/styles";

type CreateShapeDialogProps = {
    open: boolean;
    x: number;
    y: number;
    bpm: number;
    previewStartPoint: number;
    onClose: () => void;
    onCreateShape: (input: CreateShapeInput) => void;
    onChangeShape: () => void;
    editingShape: BeatShape | null;
};

export type ShapeKey =
    | {
    type: "circle";
    corners: number;
    value: number[];
}
    | {
    type: "polygon";
    corners: number;
    value: number[];
}
    | {
    type: "custom";
    corners: number;
    value: number[];
    pathData: CustomPathData;
};


type PreviewRuntimeShape = {
    path: paper.Path;
    glowMarker: paper.Path.Circle;
    marker: paper.Path.Circle;
    offset: number;
    startOffset: number;
    loopDuration: number;
    triggerOffsets: number[];
    sound: Sound;
    glow: number;
};
const colors = [appColors.orange, appColors.red, appColors.purple, appColors.lightBlue, appColors.yellow, appColors.green];
const defaultSound: Sound = {soundType: "kickDrum", note: 'C1', duration: '8n', volume: 0};

const defaultShape: ShapeKey = {
    corners: 4,
    type: "polygon",
    value: [1 / 4, 1 / 4, 1 / 4, 1 / 4],
};

const initialShapeOptions: ShapeKey[] = [
    {type: "circle", corners: 4, value: [1]},
    {
        type: "custom",
        corners: 2,
        value: [0.5, 0.5],
        pathData: {
            start: [0.21666666666666667, 0],
            segments: [
                {
                    kind: "arc",
                    through: [-6.5177993493036774e-18, -0.10644374122957938],
                    to: [-0.21666666666666667, 2.6534013981525987e-17]
                },
                {
                    kind: "arc",
                    through: [1.9553398047911033e-17, 0.10644374122957938],
                    to: [0.21666666666666667, -5.3068027963051974e-17]
                }
            ],
            baseRadius: 0.21666666666666667
        }
    },
    {type: "polygon", corners: 3, value: [1 / 3,1 / 3,1 / 3, ]},
    {type: "polygon", corners: 4, value: [1 / 4, 1 / 4, 1 / 4, 1 / 4]},
    {type: "polygon", corners: 8, value: Array(8).fill(1 / 8)},
    {type: "polygon", corners: 16, value: Array(16).fill(1 / 16)},
];


export default function CreateShapeDialog({
                                              open,
                                              x,
                                              y,
                                              bpm,
                                              previewStartPoint,
                                              onClose,
                                              onCreateShape,
                                              onChangeShape,
                                              editingShape
                                          }: CreateShapeDialogProps) {
    const [selectedShape, setSelectedShape] = useState<ShapeKey>(defaultShape)
    const [volume, setVolume] = useState(0)
    const [rotation, setRotation] = useState(0)
    const [color, setColor] = useState<string>(editingShape ? editingShape.fillColor : getRandomColor());
    const [sound, setSound] = useState<Sound>(defaultSound)

    const previewCanvas = useRef<HTMLCanvasElement | null>(null);
    const [previewCanvasReady, setPreviewCanvasReady] = useState(false);
    const previewScopeRef = useRef<paper.PaperScope | null>(null);
    const previewRuntimeRef = useRef<PreviewRuntimeShape | null>(null);
    const [play, setPlay] = useState<boolean>(true);
    const [newShape, setNewShape] = useState<boolean>(false)
    const [shapeOptions, setShapeOptions] = useState<ShapeKey[]>(initialShapeOptions);
    const [openShapeEditor, setOpenShapeEditor] = useState<boolean>(false);

    const setPreviewCanvasRef = useCallback((element: HTMLCanvasElement | null) => {
        previewCanvas.current = element;
        setPreviewCanvasReady(element !== null);
    }, []);

    useEffect(() => {
        if (editingShape !== null) {
            if (editingShape.type === "polygon") {
                setSelectedShape({
                    type: "polygon",
                    corners: editingShape.corners,
                    value: editingShape.value,
                });
            } else if (editingShape.type === "circle") {
                setSelectedShape({
                    type: "circle",
                    corners: 0,
                    value: editingShape.value,
                });
            } else if (editingShape.type === "custom") {
                setSelectedShape({
                    type: "custom",
                    corners: editingShape.pathData.segments.length,
                    value: editingShape.value,
                    pathData: editingShape.pathData,
                });
            }

            setSound(editingShape.sound);
            setVolume(editingShape?.sound?.volume);
            setRotation(editingShape.rotation);
            setColor(editingShape.fillColor);
        } else {
            reset();
        }
    }, [editingShape]);


    useEffect(() => {
        if (open) {
            if(!editingShape) {
                setColor(getRandomColor)
            }
            return;
        }

        reset();

        if (previewScopeRef.current) {
            previewScopeRef.current.view.onFrame = null;
            previewScopeRef.current.project.clear();
            previewScopeRef.current = null;
        }

        previewRuntimeRef.current = null;
    }, [open]);

    function getRandomColor() {
        return colors[Math.floor(Math.random() * (colors.length))]!
    }

    function getDifferentColor(color: string) {
        let newColor: string = getRandomColor();
        let check = newColor === color;
        while (check!){
            newColor = getRandomColor();
            check = newColor === color;
        }
        return newColor;
    }

    function getSizeFromVolume() {
        return volume * 2.5 + 90;
    }

    function onStartStop() {
        void startAudio();
        setPlay((prev) => !prev)
    }

    const handleCreate = () => {
        let input: CreateShapeInput;

        if (selectedShape.type === 'circle') {
            input = {
                type: selectedShape.type,
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                radius: getSizeFromVolume(),
                rotation: rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            }
        } else if (selectedShape.type === 'polygon') {
            input = {
                type: selectedShape.type,
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                size: getSizeFromVolume(),
                corners: selectedShape.corners,
                rotation: rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            };
        } else if (selectedShape.type === "custom") {
            const scale = getSizeFromVolume() / selectedShape.pathData.baseRadius;

            const transformedPathData = transformPathData(
                selectedShape.pathData,
                scale,
                x,
                y
            );

            input = {
                type: "custom",
                x,
                y,
                fillColor: color,
                ballColor: "white",
                offset: 0,
                lastOffset: 0,
                pathData: transformedPathData,
                rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            };
        } else {
            // Default
            input = {
                type: 'polygon',
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                size: getSizeFromVolume(),
                corners: defaultShape.corners,
                rotation: 0,
                value: defaultShape.value,
                sound: {
                    ...defaultSound,
                },
            }
        }

        onCreateShape(input);
    };

    function reset() {
        setVolume(0);
        setRotation(0);
        setColor(color)
        setSound(defaultSound)
        setSelectedShape(defaultShape)
    }

    function onSetSound(soundType: SoundType) {
        void startAudio();
        setSound((prev) => ({
            ...prev,
            soundType,
        }));
        onChangeShape();
    }

    function onSetActiveShape(key: ShapeKey) {
        onChangeShape();
        setSelectedShape(key);
        setNewShape(true);
    }

    function onSetRotation(value: number) {
        setRotation(value);
        onChangeShape();
    }

    function onSetVolunme(value: number) {
        setVolume(value);
        onChangeShape();
    }

    function createAndAddNewShape(beatValues: number[]) {
        const newShape = calculateShapePoints(beatValues);
        if (!newShape) return;

        const newShapeOption: ShapeKey = {
            type: "custom",
            corners: newShape.segments.length,
            value: beatValues,
            pathData: newShape,
        };

        const alreadyExists = shapeOptions.some(
            (shapeKey) =>
                shapeKey.type === "custom" &&
                JSON.stringify(shapeKey.value) === JSON.stringify(newShapeOption.value)
        );

        if (!alreadyExists) {
            setShapeOptions((prev) => [...prev, newShapeOption]);
        }
        setOpenShapeEditor(false);
        setSelectedShape(newShapeOption)
        setPlay(true)
    }

    function closeShapeEditor() {
        setOpenShapeEditor(false);
    }

    function openShapeEditorDialog(){
        setOpenShapeEditor(true)
        setPlay(false)
    }

    // ===================================== PREVIEW =====================================
    useEffect(() => {
        if (!open || !previewCanvasReady) return;

        const canvas = previewCanvas.current;

        if (!canvas) return;
        let scope = previewScopeRef.current;

        if(!scope) {
            scope = new paper.PaperScope();
            scope.setup(canvas);
            previewScopeRef.current = scope;
        }

        if (!play) {
            if(!newShape){
                scope.view.onFrame = null;
                return;
            }
        }

        scope.activate();
        scope.project.clear();

        const center = new scope.Point(canvas.width / 2, canvas.height / 2);

        // const scaledCustomPoints = scalePoints(selectedShape.cornerPoints, getSizeFromVolume() / 100);
        // const scaledCustomPoints = selectedShape.cornerPoints;
        // const customPreviewPoints = translatePoints(
        //     scaledCustomPoints,
        //     canvas.width / 2,
        //     canvas.height / 2
        // );

        let path: paper.Path;
        let customTriggerPoints: [number, number][] | null = null;

        if (selectedShape.type === "polygon") {
            path = new scope.Path.RegularPolygon({
                center,
                sides: selectedShape.corners,
                radius: getSizeFromVolume(),
                fillColor: color,
            });
        } else if (selectedShape.type === "custom") {
            const scale = getSizeFromVolume() / selectedShape.pathData.baseRadius;

            const transformedPathData = transformPathData(
                selectedShape.pathData,
                scale,
                canvas.width / 2,
                canvas.height / 2
            );

            customTriggerPoints = [
                transformedPathData.start,
                ...transformedPathData.segments.map((segment) => segment.to),
            ];
            path = buildPaperPath(scope, transformedPathData, color);
        } else {
            path = new scope.Path.Circle({
                center,
                radius: getSizeFromVolume(),
                fillColor: color,
            });
        }

        const triggerOffsets =
            selectedShape.type === "circle"
                ? [0]
                : customTriggerPoints !== null
                    ? customTriggerPoints
                        .map((point) =>
                            path.getOffsetOf(new scope.Point(point[0], point[1]))
                        )
                        .filter((offset): offset is number => offset !== null)
                    : path.segments
                        .map((segment) => path.getOffsetOf(segment.point))
                        .filter((offset): offset is number => offset !== null);

        path.rotation = rotation;

        const normalizedProgress = previewStartPoint;
        const phaseOffset = ((rotation ?? 0) / 360) * path.length;
        const startOffset = (normalizedProgress * path.length + phaseOffset) % path.length;

        const marker = new scope.Path.Circle({
            center: path.getPointAt(startOffset) ?? path.position,
            radius: 15,
            fillColor: appColors.black,
        });

        const glowMarker = new scope.Path.Circle({
            center: marker.position,
            radius: 22,
            fillColor: new scope.Color("#ffffff"),
        });

        glowMarker.opacity = 0;
        glowMarker.shadowColor = new scope.Color(appColors.glowColor);
        glowMarker.shadowBlur = 0;
        glowMarker.shadowOffset = new scope.Point(0, 0);
        glowMarker.insertBelow(marker);

        const loopDuration = bpm;

        previewRuntimeRef.current = {
            path,
            glowMarker,
            marker,
            offset: startOffset,
            startOffset,
            loopDuration,
            triggerOffsets,
            sound: {
                ...sound,
                volume,
            },
            glow: 0,
        };

        scope.view.onFrame = (event: { delta: number }) => {
            const runtime = previewRuntimeRef.current;
            if (!runtime) return;

            const oldOffset = runtime.offset < 0 ? runtime.startOffset : runtime.offset;
            const speed = runtime.path.length / runtime.loopDuration;
            const newOffset = (runtime.offset + speed * event.delta) % runtime.path.length;

            const triggered = checkTriggerCrossing(
                runtime.triggerOffsets,
                oldOffset,
                newOffset,
                runtime.path.length
            );

            runtime.offset = newOffset;

            if(newShape && !play){ //Shape Changes but dot doesnt move when preview is paused but a new shape is selected
                setNewShape(false)
            } else {
                runtime.marker.position =
                    runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;
                runtime.glowMarker.position = runtime.marker.position;

                if (triggered) {
                    runtime.glow = 1;
                    playSound("preview-shape", runtime.sound);
                }

                runtime.glow = Math.max(0, runtime.glow - event.delta * 1.8);
                runtime.glowMarker.opacity = runtime.glow * 0.8;
                runtime.glowMarker.shadowBlur = runtime.glow * 20;
            }
        };

    }, [open, play, newShape, previewCanvasReady, selectedShape, volume, rotation, color, sound, bpm, previewStartPoint]);

    return (
        <Dialog open={open} onClose={onClose} keepMounted PaperProps={{
            sx: {
                width: 1200,
                maxWidth: 'none',
                backgroundColor: appColors.background,
                // backgroundColor: alpha(appColors.background, 0.5),
                // borderRadius: 0,
                // boxShadow: 3,
                backdropFilter: 'blur(20px)',
            },
        }}>
            <DialogTitle variant='h2'>{editingShape ? "Spape bearbeiten" : "Shape erstellen"}</DialogTitle>
            <DialogContent>
                <Box
                    sx={{
                        display: "grid",
                        gridTemplateColumns: "1.1fr 1.2fr 0.8fr",
                        gap: 4,
                        width: "100%",
                    }}
                >
                    <Box
                        sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                        }}
                    >
                        <Typography variant='h5'>Preview</Typography>
                        <Box sx={{ display: "flex", gap: 1, width: "100%" }}>
                            {colors.map((colorOption) => (
                                <Box
                                    key={colorOption}
                                    onClick={() => setColor(colorOption)}
                                    sx={{
                                        flex: 1,
                                        height: 30,
                                        backgroundColor: colorOption,
                                        cursor: "pointer",
                                        border: color === colorOption
                                            ? `4px solid ${appColors.black}`
                                            : "4px solid transparent",
                                    }}
                                />
                            ))}
                        </Box>
                        <Box
                            sx={{
                                display: "flex",
                                justifyContent: "center",
                                alignContent: "center",
                                border: `4px solid ${appColors.black}`,
                                minWidth: 345
                            }}
                        >
                            <Box
                                sx={{
                                    position: "relative",
                                    width: 300,
                                    height: 300,
                                }}
                            >
                                <canvas
                                    ref={setPreviewCanvasRef}
                                    height={300}
                                    width={300}
                                    style={{
                                        display: "block",
                                    }}
                                />

                                <Box
                                    sx={{
                                        position: "absolute",
                                        top: 8,
                                        left: -10,
                                        zIndex: 2,
                                    }}
                                >
                                    <StartStopButton setRunning={onStartStop} running={play}/>
                                </Box>
                            </Box>
                        </Box>
                        <BeatlineWithNotes beatValues={selectedShape.value} height={84} showProgress={false}></BeatlineWithNotes>

                        {/*<VolumeSlider onChange={onSetVolume}></VolumeSlider>*/}
                        <Typography variant='h5'>Size/Volume</Typography>
                            <SliderComponent value={volume} min={-20} max={20} valueLabelDisplay={"off"} color={color} marks={[]} setValue={onSetVolunme}/>
                        <Typography variant='h5'>Rotation/Offset</Typography>
                        <SliderComponent value={rotation} min={-180} max={180} valueLabelDisplay={"auto"} color={color} marks={[]} setValue={onSetRotation} step={5}/>
                    </Box>

                    <Box
                        sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                        }}
                    >
                        <Typography variant='h4'> ShapeOptions</Typography>
                        <Box sx={{
                            maxHeight: 600,
                            overflowY: "auto",

                            // Firefox
                            scrollbarWidth: "thin",
                            scrollbarColor: `${appColors.black} transparent`,

                            // Chrome / Edge / Safari
                            "&::-webkit-scrollbar": {
                                width: 8,
                            },
                            "&::-webkit-scrollbar-track": {
                                background: "transparent",
                            },
                            "&::-webkit-scrollbar-thumb": {
                                backgroundColor: appColors.black,
                                borderRadius: 0,
                            },
                            "&::-webkit-scrollbar-thumb:hover": {
                                backgroundColor: "#333",
                            },
                        }}>
                            <Grid container spacing={1 }>
                                <Grid size={12}>
                                    <BuildNewBeatshapeButton openDialog={openShapeEditorDialog} color={color}>

                                    </BuildNewBeatshapeButton>
                                </Grid>
                                {shapeOptions.map((shape) => {
                                    return (
                                        <Grid
                                            key={`${shape.type}-${shape.corners}-${shape.value.join("-")}`}
                                            size={12}
                                        >
                                            <ShapeCard
                                                color={color}
                                                shape={shape}
                                                activeShape={selectedShape}
                                                setActiveShape={onSetActiveShape}
                                            />
                                        </Grid>
                                    );
                                })}
                            </Grid>
                        </Box>
                    </Box>

                    <Box
                        sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                        }}
                    >

                        <Typography variant='h4'> Sound </Typography>
                        <Box sx={{
                            display: "flex",
                            flexDirection: "column",
                            gap: 2,
                            maxHeight: 600,
                            overflowY: "auto",

                            // Firefox
                            scrollbarWidth: "thin",
                            scrollbarColor: `${appColors.black} transparent`,

                            // Chrome / Edge / Safari
                            "&::-webkit-scrollbar": {
                                width: 8,
                            },
                            "&::-webkit-scrollbar-track": {
                                background: "transparent",
                            },
                            "&::-webkit-scrollbar-thumb": {
                                backgroundColor: appColors.black,
                                borderRadius: 0,
                            },
                            "&::-webkit-scrollbar-thumb:hover": {
                                backgroundColor: "#333",
                            },
                        }}>
                            {soundTypes.map((soundType) => (
                                <SoundComponent
                                    key={soundType}
                                    soundType={soundType}
                                    volume={volume}
                                    activeSound={sound.soundType}
                                    setActiveSound={onSetSound}
                                    color={color}
                                >

                                </SoundComponent>
                            ))}
                        </Box>
                    </Box>
                </Box>
            </DialogContent>
            <DialogActions sx={{display: 'flex', padding: 2.5}}>
                <Button sx={{backgroundColor: appColors.black, display: 'flex', padding: 2, color: appColors.white}} onClick={onClose}>Schließen</Button>
                <Button sx={{backgroundColor: color, display: 'flex', padding: 2, color: appColors.black}} onClick={() => {
                    handleCreate();
                    onClose();
                }
                }>Erstellen</Button>
            </DialogActions>
            <ShapeEditorDialog
                open={openShapeEditor}
                onClose={closeShapeEditor}
                createCustomShape={createAndAddNewShape}
            />
            {/*<Button onClick={() => console.log(shapeOptions)}>*/}
            {/*    Shapes*/}
            {/*</Button>*/}
        </Dialog>
    );
}

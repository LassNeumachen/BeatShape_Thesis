import type { Sound } from "./sounds";

export type ShapeType = "polygon" | "circle" | "custom";

export type Point2D = [number, number];

export type LineSegment = {
    kind: "line";
    to: Point2D;
};

export type ArcSegment = {
    kind: "arc";
    to: Point2D;
    through: Point2D;
};

export type ShapeSegment = LineSegment | ArcSegment;

export type CustomPathData = {
    start: Point2D;
    segments: ShapeSegment[];
    baseRadius: number;
};

export type BeatShapeBase = {
    id: string;
    type: ShapeType;
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    startOffset: number;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    rotation: number;
    sound: Sound;
    value: number[];
};

export type PolygonBS = BeatShapeBase & {
    type: "polygon";
    size: number;
    corners: number;
};

export type CircleBS = BeatShapeBase & {
    type: "circle";
    radius: number;
};

export type CustomBS = BeatShapeBase & {
    type: "custom";
    pathData: CustomPathData;
};

export type BeatShape = PolygonBS | CircleBS | CustomBS;

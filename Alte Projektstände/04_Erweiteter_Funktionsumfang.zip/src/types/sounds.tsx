export const soundTypes = ['kickDrum','KickDrumSample', 'highHat_1','highHat_2', 'clap_1', 'clap_2'] as const;

export type SoundType = (typeof soundTypes)[number];

export type Sound = {
    soundType: SoundType,
    volume: number,
    note: string,
    duration: string,
    }
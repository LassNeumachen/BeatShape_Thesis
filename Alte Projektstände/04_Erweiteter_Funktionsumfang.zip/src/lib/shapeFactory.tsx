import type { BeatShape, CustomPathData } from '../types/shapes';
import type {Sound} from "../types/sounds";

export type CreateShapeInput =
    | {
    type: 'polygon';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    size: number;
    corners: number;
    rotation: number;
    value: number[];
    sound: Sound;
}
    | {
    type: 'circle';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    radius: number;
    rotation: number;
    value: number[];
    sound: Sound;
}
    | {
    type: 'custom';
    x: number;
    y: number;
    fillColor: string;
    ballColor: string;
    offset: number;
    lastOffset: number;
    triggerOffsets?: number[];
    pathData: CustomPathData;
    rotation: number;
    value: number[];
    sound: Sound;
};

export function createShape(input: CreateShapeInput): BeatShape {
    const base = {
        id: crypto.randomUUID(),
        type: input.type,
        x: input.x,
        y: input.y,
        fillColor: input.fillColor,
        ballColor: input.ballColor,
        startOffset: 0,
        offset: input.offset,
        lastOffset: input.lastOffset,
        rotation: input.rotation,
        value: input.value,
        sound: input.sound,
        ...(input.triggerOffsets !== undefined
            ? { triggerOffsets: input.triggerOffsets }
            : {}),
    };

    if (input.type === 'polygon') {
        return {
            ...base,
            type: 'polygon',
            size: input.size,
            corners: input.corners,
        };
    }

    if (input.type === 'circle') {
        return {
            ...base,
            type: 'circle',
            radius: input.radius,
        };
    }

    return {
        ...base,
        type: 'custom',
        pathData: input.pathData,
    };
}

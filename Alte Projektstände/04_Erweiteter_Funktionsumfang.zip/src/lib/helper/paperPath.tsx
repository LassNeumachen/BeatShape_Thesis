import paper from "paper";
import type { CustomPathData, Point2D } from "../../types/shapes";

export function transformPoint(
    [x, y]: Point2D,
    scale: number,
    offsetX: number,
    offsetY: number
): Point2D {
    return [x * scale + offsetX, y * scale + offsetY];
}

export function transformPathData(
    pathData: CustomPathData,
    scale: number,
    offsetX: number,
    offsetY: number
): CustomPathData {
    return {
        ...pathData,
        start: transformPoint(pathData.start, scale, offsetX, offsetY),
        segments: pathData.segments.map((segment) =>
            segment.kind === "line"
                ? {
                    kind: "line",
                    to: transformPoint(segment.to, scale, offsetX, offsetY),
                }
                : {
                    kind: "arc",
                    to: transformPoint(segment.to, scale, offsetX, offsetY),
                    through: transformPoint(segment.through, scale, offsetX, offsetY),
                }
        ),
    };
}

export function buildPaperPath(
    scope: paper.PaperScope,
    pathData: CustomPathData,
    fillColor: string
) {
    const path = new scope.Path();
    path.moveTo(new scope.Point(pathData.start[0], pathData.start[1]));

    for (const segment of pathData.segments) {
        if (segment.kind === "line") {
            path.lineTo(new scope.Point(segment.to[0], segment.to[1]));
        } else {
            path.arcTo(
                new scope.Point(segment.through[0], segment.through[1]),
                new scope.Point(segment.to[0], segment.to[1])
            );
        }
    }

    path.closed = true;
    path.fillColor = fillColor as never;
    return path;
}

import * as Tone from 'tone';
import type {Sound} from "../types/sounds";
import kickDrumSampleUrl from "../assets/sounds/KickDrum.mp3";

let started = false;

type SynthSoundType = Exclude<Sound["soundType"], "KickDrumSample">;

type SynthVoice = {
    kind: "synth";
    soundType: SynthSoundType;
    synth:
        | Tone.MembraneSynth
        | Tone.NoiseSynth
        | Tone.MetalSynth;
    output?: Tone.Filter;
};

type PlayerVoice = {
    kind: "player";
    soundType: "KickDrumSample";
    player: Tone.Player;
};

type ShapeVoice = SynthVoice | PlayerVoice;

const shapeVoices = new Map<string, ShapeVoice>();
const clapFilter = new Tone.Filter(1400, 'highpass').toDestination();

export const kickDrum = new Tone.MembraneSynth({
    pitchDecay: 0.05,
    octaves: 8,
    oscillator: { type: 'sine' },
    envelope: {
        attack: 0.001,
        decay: 0.4,
        sustain: 0.01,
        release: 0.8,
    },
}).toDestination();

function createClap2Voice() {
    return new Tone.NoiseSynth({
        noise: {
            type: 'white',
        },
        envelope: {
            attack: 0.001,
            decay: 0.12,
            sustain: 0,
            release: 0.03,
        },
    }).connect(clapFilter);
}

const clap2Voices = [
    createClap2Voice(),
    createClap2Voice(),
    createClap2Voice(),
    createClap2Voice(),
];

let clap2VoiceIndex = 0;

function getNextClap2Voice() {
    const voice = clap2Voices[clap2VoiceIndex];
    clap2VoiceIndex = (clap2VoiceIndex + 1) % clap2Voices.length;
    return voice;
}

export const clap_1 = new Tone.NoiseSynth({
    noise: {
        type: 'white',
    },
    envelope: {
        attack: 0.001,
        decay: 0.18,
        sustain: 0,
        release: 0.02,
    },
}).connect(new Tone.Filter(1800, 'highpass').toDestination());

export const highHat_1 = new Tone.MetalSynth({
    envelope: {
        attack: 0.001,
        decay: 0.08,
        release: 0.01,
    },
    harmonicity: 5.1,
    modulationIndex: 32,
    resonance: 3000,
    octaves: 1.5,
}).toDestination();

export const highHat_2 = new Tone.MetalSynth({
    envelope: {
        attack: 0.001,
        decay: 0.05,
        release: 0.01,
    },
    harmonicity: 7,
    modulationIndex: 40,
    resonance: 5000,
    octaves: 2,
}).toDestination();
// ============================================================================================

function createVoice(soundType: Sound["soundType"]): ShapeVoice {
    switch (soundType) {
        case "KickDrumSample":
            return {
                kind: "player",
                soundType,
                player: new Tone.Player(kickDrumSampleUrl).toDestination(),
            };

        case "kickDrum":
            return {
                kind: "synth",
                soundType,
                synth: new Tone.MembraneSynth({
                    pitchDecay: 0.05,
                    octaves: 8,
                    oscillator: { type: "sine" },
                    envelope: {
                        attack: 0.001,
                        decay: 0.4,
                        sustain: 0.01,
                        release: 0.8,
                    },
                }).toDestination(),
            };

        case "clap_1": {
            const filter = new Tone.Filter(1800, "highpass").toDestination();
            return {
                kind: "synth",
                soundType,
                synth: new Tone.NoiseSynth({
                    noise: { type: "white" },
                    envelope: {
                        attack: 0.001,
                        decay: 0.18,
                        sustain: 0,
                        release: 0.02,
                    },
                }).connect(filter),
                output: filter,
            };
        }

        case "highHat_1":
            return {
                kind: "synth",
                soundType,
                synth: new Tone.MetalSynth({
                    envelope: {
                        attack: 0.001,
                        decay: 0.08,
                        release: 0.01,
                    },
                    harmonicity: 5.1,
                    modulationIndex: 32,
                    resonance: 3000,
                    octaves: 1.5,
                }).toDestination(),
            };

        case "highHat_2":
            return {
                kind: "synth",
                soundType,
                synth: new Tone.MetalSynth({
                    envelope: {
                        attack: 0.001,
                        decay: 0.05,
                        release: 0.01,
                    },
                    harmonicity: 7,
                    modulationIndex: 40,
                    resonance: 5000,
                    octaves: 2,
                }).toDestination(),
            };

        case "clap_2": {
            const filter = new Tone.Filter(1400, "highpass").toDestination();
            return {
                kind: "synth",
                soundType,
                synth: new Tone.NoiseSynth({
                    noise: { type: "white" },
                    envelope: {
                        attack: 0.001,
                        decay: 0.12,
                        sustain: 0,
                        release: 0.03,
                    },
                }).connect(filter),
                output: filter,
            };
        }
    }
}

function disposeVoice(voice: ShapeVoice) {
    if (voice.kind === "player") {
        voice.player.dispose();
        return;
    }

    voice.synth.dispose();
    voice.output?.dispose();
}

function getOrCreateVoice(shapeId: string, soundType: Sound["soundType"]) {
    const existing = shapeVoices.get(shapeId);

    if (existing && existing.soundType === soundType) {
        return existing;
    }

    if (existing) {
        disposeVoice(existing);
        shapeVoices.delete(shapeId);
    }

    const voice = createVoice(soundType);
    shapeVoices.set(shapeId, voice);
    return voice;
}


export function testSound(note: string = 'C1', duration: string = '8n') {
    if (!started) return;
    const now = Tone.now();

    highHat_2.triggerAttackRelease('C1','16n');

    // clap_1.triggerAttackRelease('32n', now);
    // clap_1.triggerAttackRelease('32n', now + 0.015);
    // clap_1.triggerAttackRelease('32n', now + 0.03);
}

// ============================================================================================

export function playSound(shapeId: string, sound: Sound) {
    if (!started) return;

    const voice = getOrCreateVoice(shapeId, sound.soundType);

    if (voice.kind === "player") {
        voice.player.volume.value = sound.volume;

        if (voice.player.loaded) {
            voice.player.start();
        } else {
            void Tone.loaded().then(() => voice.player.start());
        }
        return;
    }

    voice.synth.volume.value = sound.volume;

    switch (sound.soundType) {
        case "kickDrum":
            (voice.synth as Tone.MembraneSynth).triggerAttackRelease(sound.note, sound.duration);
            break;
        case "KickDrumSample":
            break;
        case "clap_1":
            (voice.synth as Tone.NoiseSynth).triggerAttackRelease("16n");
            break;
        case "clap_2": {
            const now = Tone.now();
            const synth = voice.synth as Tone.NoiseSynth;
            synth.triggerAttackRelease("32n", now);
            synth.triggerAttackRelease("32n", now + 0.015);
            synth.triggerAttackRelease("32n", now + 0.03);
            break;
        }
        case "highHat_1":
            (voice.synth as Tone.MetalSynth).triggerAttackRelease("C-4", "16n");
            break;
        case "highHat_2":
            (voice.synth as Tone.MetalSynth).triggerAttackRelease("C-4", "16n");
            break;
    }
}

export function disposeShapeSound(shapeId: string) {
    const voice = shapeVoices.get(shapeId);
    if (!voice) return;

    disposeVoice(voice);
    shapeVoices.delete(shapeId);
}

export function disposeAllSounds() {
    for (const [shapeId, voice] of shapeVoices) {
        disposeVoice(voice);
        shapeVoices.delete(shapeId);
    }
}

// ============================================================================================

export async function startAudio() {
    if (started) return;
    await Tone.start();
    started = true;
}

export async function suspendAudio() {
    if(!started) return;
    // @ts-ignore
    await Tone.getContext().rawContext.suspend();
}

export async function resumeAudio() {
    if(!started) return;
    await Tone.getContext().rawContext.resume();
}

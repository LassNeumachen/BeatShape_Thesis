import {Box, Button, Grid, Typography} from '@mui/material';
import {useEffect, useRef, useState} from 'react';
import CreateShapeDialog from '../Dialogs/CreateShapeDialog';
import {type BeatShape} from '../types/shapes';
import {createShape, type CreateShapeInput} from '../lib/shapeFactory';
import paper from 'paper';
import {playSound, startAudio} from '../lib/audioEngine';
import type {Sound} from "../types/sounds";
import SoundToggleButton from "../components/Buttons/MuteButtonComponent";
import StartStopButton from "../components/Buttons/StopPlayButtonComponent";
import {checkTriggerCrossing} from "../lib/helper/TriggerHelper";
import {buildPaperPath} from "../lib/helper/paperPath";
import MetronomeComponent from "../components/MetronomeComponent";
import SliderComponent from "../components/SliderComponent";
import { appColors } from "../theme";

type StageProps = {
    onStageClick?: (x: number, y: number) => void;
};

type RuntimeShape = {
    id: string;
    path: paper.Path;
    glowMarker: paper.Path.Circle;
    marker: paper.Path.Circle;
    startOffset: number;
    offset: number;
    loopDuration: number;
    triggerOffsets: number[];
    sound: Sound;
    glow: number;
};

type MetronomeRuntime = {
    path: paper.Path;
    offset: number;
    triggerOffsets: number[];
};

export default function Stage({onStageClick}: StageProps) {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const paperScopeRef = useRef<paper.PaperScope | null>(null);

    const [coordinates, setCoordinates] = useState<{ x: number; y: number }>({x: 0, y: 0});
    const [mousePosition, setMousePosition] = useState<{ x: number; y: number }>({x: 0, y: 0});
    const [manageDialog, setManageDialog] = useState(false);
    const [shapes, setShapes] = useState<BeatShape[]>([]);
    const runtimeShapesRef = useRef<RuntimeShape[]>([]);
    const metronomeRuntimeRef = useRef<MetronomeRuntime | null>(null);
    const [bpm, setBpm] = useState<number>(120)
    const [sekToEncircle, setSekToEncircle] = useState<number>(2)
    const [play, setPlay] = useState<boolean>(true);
    const [muted, setMuted] = useState<boolean>(false);
    const [volume, setVolume] = useState<number>(50);

    const [editingShape, setEditingShape] = useState<BeatShape | null>(null);
    const [draggingShapeId, setDraggingShapeId] = useState<string | null>(null);
    const dragOffsetRef = useRef<{ x: number; y: number }>({x: 0, y: 0});
    const wasDraggingRef = useRef(false);

    const activeBeatRef = useRef(0);
    const [activeBeat, setActiveBeat] = useState(0);

    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        scope.activate();
        scope.project.clear();
        setupMetronomeRuntime(scope);

        runtimeShapesRef.current = shapes.map((shape) => {
            let path: paper.Path;

            if (shape.type === 'polygon') {
                path = new scope.Path.RegularPolygon({
                    center: new scope.Point(shape.x, shape.y),
                    sides: shape.corners,
                    radius: shape.size,
                    fillColor: shape.fillColor,
                    sound: shape.sound,
                });
            } else if (shape.type === 'circle') {
                path = new scope.Path.Circle({
                    center: new scope.Point(shape.x, shape.y),
                    radius: shape.radius,
                    fillColor: shape.fillColor,
                    sound: shape.sound,
                });
            } else {
                path = buildPaperPath(scope, shape.pathData, shape.fillColor);
            }
            path.data.sound = shape.sound;
            path.data.shapeId = shape.id;

            const triggerOffsets =
                shape.type === 'circle'
                    ? [0]
                    : shape.type === 'custom'
                        ? [
                            shape.pathData.start,
                            ...shape.pathData.segments.map((segment) => segment.to),
                        ]
                            .map((point) =>
                                path.getOffsetOf(new scope.Point(point[0], point[1]))
                            )
                            .filter((offset): offset is number => offset !== null)
                        : path.segments
                            .map((segment) => path.getOffsetOf(segment.point))
                            .filter((offset): offset is number => offset !== null);

            if (shape.rotation !== undefined) {
                path.rotation = shape.rotation
            }
            const phaseOffset = ((shape.rotation ?? 0) / 360) * path.length;

            const startOffset = phaseOffset % path.length;
            // const triggerOffsets = shape.type === 'circle' ? [0] : path.segments.map((segment) => path.getOffsetOf(segment.point)).filter((offset): offset is number => offset !== null);

            const marker = new scope.Path.Circle({
                center: path.getPointAt(startOffset) ?? path.position,
                radius: 15,
                fillColor: 'FFFFFF',
            });

            const glowMarker = new scope.Path.Circle({
                center: marker.position,
                radius: 22,
                fillColor: new scope.Color("#ffffff"),
            });

            glowMarker.opacity = 0;
            glowMarker.shadowColor = new scope.Color(appColors.glowColor);
            glowMarker.shadowBlur = 0;
            glowMarker.shadowOffset = new scope.Point(0, 0);
            glowMarker.insertBelow(marker);

            return {
                id: shape.id,
                path,
                glowMarker,
                marker,
                offset: startOffset,
                startOffset,
                loopDuration: sekToEncircle,
                triggerOffsets,
                sound: shape.sound,
                glow: 0
            };

        });
    }, [shapes, sekToEncircle]);


    useEffect(() => {
        if (!canvasRef.current) return;

        const scope = new paper.PaperScope();
        scope.setup(canvasRef.current);
        paperScopeRef.current = scope;

        setupMetronomeRuntime(scope);

        return () => {
            scope.project.clear();
            metronomeRuntimeRef.current = null;
        };
    }, []);


    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        if (!play) {
            scope.view.onFrame = null;
            return;
        }

        scope.view.onFrame = (event: { delta: number }) => {
            updateMetronome(event.delta);

            for (const runtime of runtimeShapesRef.current) {
                const oldOffset = runtime.offset;
                const speed = runtime.path.length / runtime.loopDuration;
                const newOffset = (runtime.offset + speed * event.delta) % runtime.path.length;


                const triggered = checkTriggerCrossing(
                    runtime.triggerOffsets,
                    oldOffset,
                    newOffset,
                    runtime.path.length
                );

                runtime.offset = newOffset;

                runtime.marker.position =
                    runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;

                runtime.glowMarker.position = runtime.marker.position;

                if (triggered) {
                    runtime.glow = 1;

                    if (!muted) {
                        playSound(runtime.id, runtime.sound);
                    }
                }

                runtime.glow = Math.max(0, runtime.glow - event.delta * 1.8);
                runtime.glowMarker.opacity = runtime.glow * 0.8;
                runtime.glowMarker.shadowBlur = runtime.glow * 20;
            }
        };

        return () => {
            scope.view.onFrame = null;
        };
    }, [play, muted, sekToEncircle]);

    function setupMetronomeRuntime(scope: paper.PaperScope) {
        const path = new scope.Path.RegularPolygon({
            center: new scope.Point(-1000, -1000),
            sides: 4,
            radius: 100,
        });

        path.visible = false;

        const triggerOffsets = path.segments
            .map((segment) => path.getOffsetOf(segment.point))
            .filter((offset): offset is number => offset !== null);

        metronomeRuntimeRef.current = {
            path,
            offset: 0,
            triggerOffsets,
        };
    }

    function updateMetronome(delta: number) {
        const metronome = metronomeRuntimeRef.current;
        if (!metronome) return;

        const oldOffset = metronome.offset;
        const speed = metronome.path.length / sekToEncircle;
        const newOffset = (metronome.offset + speed * delta) % metronome.path.length;

        const triggered = checkTriggerCrossing(
            metronome.triggerOffsets,
            oldOffset,
            newOffset,
            metronome.path.length
        );

        metronome.offset = newOffset;

        if (triggered) {
            activeBeatRef.current = (activeBeatRef.current + 1) % 4;
            setActiveBeat(activeBeatRef.current);
        }
    }

    function resetAllRuntimeShapes() {
        activeBeatRef.current = 0;
        setActiveBeat(0);

        if (metronomeRuntimeRef.current) {
            metronomeRuntimeRef.current.offset = 0;
        }

        for (const runtime of runtimeShapesRef.current) {
            runtime.offset = runtime.startOffset;
            runtime.marker.position =
                runtime.path.getPointAt(runtime.startOffset) ?? runtime.path.position;

            runtime.glowMarker.position = runtime.marker.position;

        }
    }


    function syncRuntimeOffsetsToShapes() {
        setShapes((prevShapes) =>
            prevShapes.map((shape) => {
                const runtime = runtimeShapesRef.current.find((item) => item.id === shape.id);
                if (!runtime) return shape;

                return {
                    ...shape,
                    offset: runtime.offset,
                    lastOffset: runtime.offset,
                };
            })
        );
    }


    function handleClick(event: React.MouseEvent<HTMLDivElement>) {
        void startAudio();

        if (wasDraggingRef.current) {
            wasDraggingRef.current = false;
            return;
        }

        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() !== 'canvas' || target.id !== 'MainCanvas') {
            return;
        }

        const scope = paperScopeRef.current;
        if (!scope || !canvasRef.current) return;

        const rect = canvasRef.current.getBoundingClientRect();
        const canvasX = event.clientX - rect.left;
        const canvasY = event.clientY - rect.top;

        onStageClick?.(canvasX, canvasY);

        const hitResult = scope.project.hitTest(new scope.Point(canvasX, canvasY), {
            fill: true,
            stroke: true,
            tolerance: 8,
        });

        const hitShapeId = hitResult?.item?.data?.shapeId;

        resetAllRuntimeShapes();
        syncRuntimeOffsetsToShapes();

        if (hitShapeId) {
            const foundShape = shapes.find((shape) => shape.id === hitShapeId) ?? null;
            setEditingShape(foundShape);

            if (foundShape) {
                setCoordinates({x: foundShape.x, y: foundShape.y});
            }
        } else {
            setEditingShape(null);
            setCoordinates({x: canvasX, y: canvasY});
        }

        setManageDialog(true);
    }


    function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
        if (!draggingShapeId) return;
        wasDraggingRef.current = true;

        setMousePosition({
            x: event.clientX,
            y: event.clientY,
        });

        const point = getCanvasPoint(event);
        if (!point) return;

        const runtime = runtimeShapesRef.current.find((item) => item.id === draggingShapeId);
        if (!runtime) return;

        runtime.path.position = new paper.Point(
            point.x + dragOffsetRef.current.x,
            point.y + dragOffsetRef.current.y
        );
        runtime.marker.position =
            runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;
    }


    function handleCloseDialog() {
        setManageDialog(false);
        setEditingShape(null);
    }

    function onSetMuted() {
        setMuted((prev) => !prev);
    }

    function onStartStop() {
        void startAudio();
        setPlay((prev) => !prev)
    }

    function setNewSpeed(speed: number) {
        setBpm(speed);
        setSekToEncircle((60 / speed) * 4)
    }

    function getCanvasPoint(event: React.MouseEvent<HTMLDivElement>) {
        if (!canvasRef.current || !paperScopeRef.current) return null;

        const rect = canvasRef.current.getBoundingClientRect();
        return new paperScopeRef.current.Point(
            event.clientX - rect.left,
            event.clientY - rect.top
        );
    }

    const bpmMarks = [
        { value: 80, label: '80' },
        { value: 100, label: '100' },
        { value: 120, label: '120' },
        { value: 140, label: '140' },
        { value: 160, label: '160' },
    ];

    function handleMouseDown(event: React.MouseEvent<HTMLDivElement>) {
        void startAudio();

        wasDraggingRef.current = false;
        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() !== 'canvas' || target.id !== 'MainCanvas') {
            return;
        }

        const scope = paperScopeRef.current;
        if (!scope) return;

        const point = getCanvasPoint(event);
        if (!point) return;

        const hitResult = scope.project.hitTest(point, {
            fill: true,
            stroke: true,
            tolerance: 8,
        });

        const hitShapeId = hitResult?.item?.data?.shapeId;

        if (!hitShapeId) {
            setDraggingShapeId(null);
            return;
        }

        const runtime = runtimeShapesRef.current.find((item) => item.id === hitShapeId);
        if (!runtime) return;

        setDraggingShapeId(hitShapeId);

        dragOffsetRef.current = {
            x: runtime.path.position.x - point.x,
            y: runtime.path.position.y - point.y,
        };
    }

    function handleMouseUp() {
        if (!draggingShapeId) return;

        const runtime = runtimeShapesRef.current.find((item) => item.id === draggingShapeId);
        if (!runtime) {
            setDraggingShapeId(null);
            return;
        }

        setShapes((prev) =>
            prev.map((shape) => {
                if (shape.id !== draggingShapeId) return shape;

                if (shape.type === 'custom') {
                    return {
                        ...shape,
                        x: runtime.path.position.x,
                        y: runtime.path.position.y,
                        pathData: {
                            ...shape.pathData,
                            start: [
                                shape.pathData.start[0] + runtime.path.position.x - shape.x,
                                shape.pathData.start[1] + runtime.path.position.y - shape.y,
                            ],
                            segments: shape.pathData.segments.map((segment) =>
                                segment.kind === "line"
                                    ? {
                                        ...segment,
                                        to: [
                                            segment.to[0] + runtime.path.position.x - shape.x,
                                            segment.to[1] + runtime.path.position.y - shape.y,
                                        ],
                                    }
                                    : {
                                        ...segment,
                                        to: [
                                            segment.to[0] + runtime.path.position.x - shape.x,
                                            segment.to[1] + runtime.path.position.y - shape.y,
                                        ],
                                        through: [
                                            segment.through[0] + runtime.path.position.x - shape.x,
                                            segment.through[1] + runtime.path.position.y - shape.y,
                                        ],
                                    }
                            ),
                        },
                    };
                }

                return {
                    ...shape,
                    x: runtime.path.position.x,
                    y: runtime.path.position.y,
                };
            })
        );

        setDraggingShapeId(null);
    }

    function changeVolume(value: number) {
        setVolume(value);
    }

    return (
        <Box
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onClick={handleClick}
            onMouseMove={handleMouseMove}
            sx={{
                width: '100vw',
                height: '100vh',
                backgroundColor: 'rgb(242,235,220)',
                position: 'relative',
                overflow: 'hidden',
                display: 'flex'
            }}
        >
            <canvas
                ref={canvasRef}
                id="MainCanvas"
                width={window.innerWidth}
                height={window.innerHeight}
                style={{
                    position: 'absolute',
                    inset: 0,
                    width: '100%',
                    height: '100%',
                    display: 'block',
                    zIndex: 0,
                }}
            />
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    position: 'absolute',
                    top: 16,
                    left: 16,
                    zIndex: 10,
                }}
            >
                <Typography variant="h1"
                    sx={{
                        display: 'flex',
                        mt: 0.54
                    }}>
                    Beatshape
                </Typography>
                <Box
                    sx={{
                        display: 'flex',
                        bgcolor: appColors.black,
                        height: 46,
                        width: 46,
                        ml: 1.3,
                        mt: 1.4
                    }}
                />            </Box>
            <Box
                sx={{
                    position: 'absolute',
                    top: 16,
                    right: 16,
                    zIndex: 10,
                }}
            >
                <MetronomeComponent activeBeat={activeBeat}/>
            </Box>

            <Box
                sx={{
                    position: 'absolute',
                    bottom: 16,
                    right: 16,
                    zIndex: 10,
                    display: 'grid',
                    p: 3,
                    gridTemplateColumns: '150px 1fr',
                    alignItems: 'center',
                    rowGap: 3,
                    backgroundColor: 'rgba(255,255,255,0.5)',
                    boxShadow: 3,
                    backdropFilter: 'blur(8px)',
                }}
            >
                <Box>
                    {/*<Typography variant="h5">PAUSE/PLAY</Typography>*/}
                </Box>
                <Box sx={{display: 'flex', flexDirection: 'row'}}>

                    <StartStopButton setRunning={onStartStop} running={play}/>

                    <SoundToggleButton
                        muted={muted}
                        setMuted={onSetMuted}
                    />
                </Box>



                <Typography variant="h5">BPM</Typography>
                <SliderComponent value={bpm} min={80} max={160} valueLabelDisplay={"on"} color={"#87a574"} marks={[]} setValue={setNewSpeed}></SliderComponent>
                <Typography variant="h5">Volume</Typography>
                <SliderComponent value={volume} min={0} max={100} valueLabelDisplay={"auto"} color={"#f1cf72"} marks={[]} setValue={changeVolume}></SliderComponent>

                <Box sx={{display: "flex", alignItems: "center", gap: 2}}>


                </Box>


            </Box>


            {/*<Box*/}
            {/*                sx={{*/}
            {/*                    position: 'fixed',*/}
            {/*                    left: manageDialog ? coordinates.x : mousePosition.x,*/}
            {/*                    top: manageDialog ? coordinates.y : mousePosition.y,*/}
            {/*                    transform: 'translate(-50%, -50%)',*/}
            {/*                    width: 44,*/}
            {/*                    height: 44,*/}
            {/*                    borderRadius: '50%',*/}
            {/*                    backgroundColor: 'rgba(255,255,255,0.2)',*/}
            {/*                    display: 'flex',*/}
            {/*                    alignItems: 'center',*/}
            {/*                    justifyContent: 'center',*/}
            {/*                    pointerEvents: 'none',*/}
            {/*                    zIndex: 20,*/}
            {/*                }}*/}
            {/*            >*/}
            {/*                /!*<Box*!/*/}
            {/*                /!*    component="span"*!/*/}
            {/*                /!*    sx={{*!/*/}
            {/*                /!*        fontSize: 24,*!/*/}
            {/*                /!*        lineHeight: 1,*!/*/}
            {/*                /!*        display: 'block',*!/*/}
            {/*                /!*        transform: 'translateY(2px)',*!/*/}
            {/*                /!*    }}*!/*/}
            {/*                /!*>*!/*/}
            {/*                /!*    +*!/*/}
            {/*                /!*</Box>*!/*/}
            {/*            </Box>*/}

            {/*{!manageDialog && (*/}
            {/*    <Box*/}
            {/*        sx={{*/}
            {/*            position: 'fixed',*/}
            {/*            left: mousePosition.x + 30,*/}
            {/*            top: mousePosition.y,*/}
            {/*            transform: 'translateY(-50%)',*/}
            {/*            pointerEvents: 'none',*/}
            {/*            zIndex: 20,*/}
            {/*        }}*/}
            {/*    >*/}
            {/*        <Typography sx={{ fontSize: 14 }}>*/}
            {/*            Shape platzieren*/}
            {/*        </Typography>*/}
            {/*    </Box>*/}
            {/*)}*/}
            {manageDialog && (
                <CreateShapeDialog
                    open={manageDialog}
                    onClose={handleCloseDialog}
                    onChangeShape={resetAllRuntimeShapes}
                    onCreateShape={(input: CreateShapeInput) => {
                        if (editingShape) {
                            setShapes((prev) =>
                                prev.map((shape) =>
                                    shape.id === editingShape.id
                                        ? {...createShape(input), id: editingShape.id}
                                        : shape
                                )
                            );
                            setEditingShape(null);
                        } else {
                            setShapes((prev) => [...prev, createShape(input)]);
                        }
                    }}
                    editingShape={editingShape}
                    x={editingShape ? editingShape.x : coordinates.x}
                    y={editingShape ? editingShape.y : coordinates.y}
                    bpm={sekToEncircle}
                    previewStartPoint={0}
                />
            )}
        </Box>
    );
}

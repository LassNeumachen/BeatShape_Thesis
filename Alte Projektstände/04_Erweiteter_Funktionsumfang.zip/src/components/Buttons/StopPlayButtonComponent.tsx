import IconButton from "@mui/material/IconButton";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import PauseIcon from '@mui/icons-material/Pause';
import { appColors } from "../../theme";

export type ToggleButtonProps = {
    setRunning: () => void;
    running: boolean;
};

export default function StartStopButton(props: ToggleButtonProps) {
    return (
        <IconButton
            disableRipple
            onClick={() => props.setRunning()}
            sx={{
                paddingLeft: 0,
                backgroundColor: "transparent",
                "&:hover": { backgroundColor: "transparent" },
            }}
        >
            {props.running ? (
                <PauseIcon sx={{ fontSize: 30, color: appColors.black  }} />
            ) : (
                <PlayArrowIcon sx={{ fontSize: 30, color: appColors.black  }} />
            )}
        </IconButton>
    );
}

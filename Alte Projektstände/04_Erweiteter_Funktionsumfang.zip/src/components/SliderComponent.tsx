import Slider from "@mui/material/Slider";
import { appColors } from "../theme";

export type SliderProps = {
    value: number;
    min: number;
    max: number;
    valueLabelDisplay: "on" | "off" | "auto";
    color: string;
    marks: {value: number, label: string}[];
    setValue: (value: number) => void;
    step?: number;
}

export default function SliderComponent(props: SliderProps) {
    return (
        <Slider
            value={props.value}
            onChange={(_, value) => props.setValue(value as number)}
            min={props.min}
            max={props.max}
            step={props.step ?? 1}
            marks={props.marks}
            valueLabelDisplay = {props.valueLabelDisplay}
            valueLabelFormat={(value) => `${value}`}
            sx={{
                width: 230,
                color: appColors.black,

                "& .MuiSlider-rail": {
                    height: 8,
                    opacity: 1,
                    backgroundColor: appColors.black,
                    borderRadius: 0,
                },

                "& .MuiSlider-track": {
                    height: 8,
                    backgroundColor: appColors.black,
                    border: "none",
                    borderRadius: 0,
                },

                "& .MuiSlider-thumb": {
                    width: 30,
                    height: 30,
                    backgroundColor: props.color,
                    boxShadow: "none",
                    border: "none",
                    "&:hover, &.Mui-focusVisible": {
                        boxShadow: "none",
                    },
                },

                "& .MuiSlider-valueLabel": {
                    backgroundColor: props.color,
                    color: appColors.black,
                    fontFamily: '"Inter", sans-serif',
                    fontSize: 12,
                    fontWeight: 600,
                    lineHeight: 1,
                    borderRadius: 0,
                    padding: "2px 8px",
                    top: -6,
                },

                "& .MuiSlider-valueLabel::before": {
                    display: "none",
                },
            }}
        />
    )
}

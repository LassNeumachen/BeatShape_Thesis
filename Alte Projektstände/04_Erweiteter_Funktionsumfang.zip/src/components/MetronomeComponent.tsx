import {useEffect, useRef} from "react";
import {Box} from "@mui/material";
import paper from "paper";
import {appColors} from "../theme";

type MetronomeProps = {
    activeBeat: number;
};


export default function MetronomeComponent({ activeBeat }: MetronomeProps) {
    const metronomCanvasRef = useRef<HTMLCanvasElement | null>(null);
    const circlesRef = useRef<paper.Path.Circle[]>([]);
    const scopeRef = useRef<paper.PaperScope | null>(null);

    useEffect(() => {
        if (!metronomCanvasRef.current) return;

        const scope = new paper.PaperScope();
        scope.setup(metronomCanvasRef.current);
        scopeRef.current = scope;
        scope.project.clear();

        circlesRef.current = [
            new scope.Path.Circle({
                center: [30, 34],
                radius: 25,
                fillColor: activeColor(scope),
            }),
            new scope.Path.Circle({
                center: [85, 34],
                radius: 25,
                fillColor: inactiveColor(scope),
            }),
            new scope.Path.Circle({
                center: [140, 34],
                radius: 25,
                fillColor: inactiveColor(scope),
            }),
            new scope.Path.Circle({
                center: [195, 34],
                radius: 25,
                fillColor: inactiveColor(scope),
            }),
        ];

        // circlesRef.current = [
        //     new scope.Path.Rectangle({
        //         point: [5, 9],
        //         size: [50, 50],
        //         fillColor: activeColor(scope),
        //     }),
        //     new scope.Path.Rectangle({
        //         point: [60, 9],
        //         size: [50, 50],
        //         fillColor: inactiveColor(scope),
        //     }),
        //     new scope.Path.Rectangle({
        //         point: [115, 9],
        //         size: [50, 50],
        //         fillColor: inactiveColor(scope),
        //     }),
        //     new scope.Path.Rectangle({
        //         point: [170, 9],
        //         size: [50, 50],
        //         fillColor: inactiveColor(scope),
        //     }),
        // ];

        return () => {
            scope.project.clear();
            circlesRef.current = [];
        };
    }, []);

    useEffect(() => {
        setActiveBeat(activeBeat);
    }, [activeBeat]);

    function activeColor(scope: paper.PaperScope) {
        return new scope.Color(appColors.black);
    }

    function inactiveColor(scope: paper.PaperScope) {
        return new scope.Color(appColors.lightBlack);
    }


    function setActiveBeat(index: number) {
        const scope = scopeRef.current;
        if (!scope) return;

        circlesRef.current.forEach((circle, i) => {
            circle.fillColor = i === index
                ? activeColor(scope)
                : inactiveColor(scope);
        });
    }


    return (
        <Box>
            <canvas
                ref={metronomCanvasRef}
                id="metronom"
                width={225}
                height={70}
            />
        </Box>
    );
}

import {memo, useEffect, useRef} from "react";
import paper from "paper";
import ToggleButton from "@mui/material/ToggleButton";
import type { ShapeKey } from "../Dialogs/CreateShapeDialog";
import { buildPaperPath, transformPathData } from "../lib/helper/paperPath";
import {Box, Typography} from "@mui/material";
import { formatBeatValuesLabel } from "../lib/helper/beatValueFormatter";
import { appColors } from "../theme";
import BeatlineWithNotes from "./BeatlineWithNotes";
import { alpha } from "@mui/material/styles";

export type ShapeCardProps = {
    color: string;
    shape: ShapeKey;
    activeShape: ShapeKey;
    setActiveShape: (key: ShapeKey) => void;
};

export function ShapeCard(props: ShapeCardProps) {
    const shapeCanvas = useRef<HTMLCanvasElement | null>(null);

    const sameValues =
        props.shape.value.length === props.activeShape.value.length &&
        props.shape.value.every((value, index) => value === props.activeShape.value[index]);

    const isSelected =
        props.shape.type === props.activeShape.type &&
        props.shape.corners === props.activeShape.corners &&
        sameValues;

    useEffect(() => {
        if (!shapeCanvas.current) return;

        const scope = new paper.PaperScope();
        scope.setup(shapeCanvas.current);
        scope.project.clear();

        const center = new scope.Point(
            shapeCanvas.current.width / 2,
            shapeCanvas.current.height / 2
        );

        if (props.shape.type === "polygon") {
            new scope.Path.RegularPolygon({
                center,
                sides: props.shape.corners,
                radius: 26,
                fillColor: appColors.black,
            });
        } else if (props.shape.type === "circle") {
            new scope.Path.Circle({
                center,
                radius: 26,
                fillColor: appColors.black,
            });
        } else if (props.shape.type === "custom") {
            const targetRadius = 26;
            const scale = targetRadius / props.shape.pathData.baseRadius;

            const transformedPathData = transformPathData(
                props.shape.pathData,
                scale,
                shapeCanvas.current.width / 2,
                shapeCanvas.current.height / 2
            );

            buildPaperPath(scope, transformedPathData, appColors.black);
        }

        return () => {
            scope.project.clear();
        };
    }, [props.shape, props.color]);

    return (
        <ToggleButton
            sx={{
                width: '100%',
                display: 'flex',
                justifyContent: 'start',
                border: !isSelected ? `0px solid ${appColors.black}` : `4px solid ${appColors.black}`,
                borderRadius: 0,
                p: 0.5,
                pl: 2,
                bgcolor: isSelected ? props.color : alpha(props.color, 0.14) ,

                "&.Mui-selected": {
                    bgcolor: appColors.background,
                },

            }}
            value={`${props.shape.type}-${props.shape.corners}`}
            selected={isSelected}
            onChange={() => props.setActiveShape(props.shape)}
        >
            <canvas ref={shapeCanvas} data-role="shapeCard" width={60} height={60} />
            <Box sx={{
                flex: 1,
                minWidth: 0,
                pt: 1
            }}>
                <BeatlineWithNotes beatValues={props.shape.value} height={70} showProgress={false}></BeatlineWithNotes>
            </Box>
        </ToggleButton>
    );
}

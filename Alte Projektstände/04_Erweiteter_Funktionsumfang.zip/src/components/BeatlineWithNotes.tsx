import {Box, LinearProgress} from "@mui/material";
import beatLine from "../assets/Taktlinie.svg"
import ganzeNote from "../assets/Notes/Noten_Ganze_Note.svg"
import halbeNote from "../assets/Notes/Noten_Halbe_Note.svg"
import viertelNote from "../assets/Notes/Noten_Viertel_Note.svg"
import achtelNote from "../assets/Notes/Noten_Achtel_Note.svg"
import achtelEnd from "../assets/Notes/Noten_Achtel_End.svg"
import achtelEndLong from "../assets/Notes/Noten_Achtel_End_Long.svg"
import sechzehntelNote from "../assets/Notes/Noten_Sechzehntel_Note.svg"
import sechzehntelNoteEnd from "../assets/Notes/Noten_Sechzehntel_Note_End.svg"
import sechzehntelNoteEndLong from "../assets/Notes/Noten_Sechzehntel_Note_End_Long.svg"
import zweiunddreissigstelNote from "../assets/Notes/Noten_Zweiunddreißigstel_Note.svg"
import zweiunddreissigstelNoteEnd from "../assets/Notes/Noten_Zweiunddreißigstel_Note_End.svg"
import dotted from "../assets/Notes/Punktiert.svg"
import doubleDotted from "../assets/Notes/DoppeltPunktiert.svg"
import {memo, useLayoutEffect, useMemo, useRef, useState} from "react";

type BeatlineWithNotesProps = {
    beatValues: number[];
    height?: number;
    showProgress: boolean;
};

type NoteImageData = {
    noteSrc: string;
    dotSrc?: string;
};

function BeatlineWithNotes(props: BeatlineWithNotesProps) {
    const height = props.height ?? 90;
    const containerRef = useRef<HTMLDivElement | null>(null);
    const [containerWidth, setContainerWidth] = useState(0);
    const [beatSlotsSegment, setBeatSlotsSegment] = useState<{ start: number; end: number }>({start: 0, end: 0});
    const [beatSpace, setBeatSpace] = useState<number>(0);
    const availableSlots: number = 32;
    const slotsToCords = Array.from({length: availableSlots + 1}, (_, i) =>
        beatSlotsSegment.start + (beatSpace * i) / availableSlots
    );
    const cordsForNotes = useMemo(
        () => getNoteScaleAndPosition(props.beatValues),
        [props.beatValues]
    );
    const smallestValue = useMemo(() => props.beatValues.length > 0 ? Math.min(...props.beatValues) : 0
        , [props.beatValues])

    const noteLayout = useMemo(
        () => getNoteLayout(height),
        [height, smallestValue]
    );
    const beatValue = useMemo(
        () => props.beatValues.reduce((sum, value) => sum + value, 0),
        [props.beatValues]
    );

    useLayoutEffect(() => {
        if (!containerRef.current) return;

        const element = containerRef.current;

        function updateSize() {
            const rect = element.getBoundingClientRect();
            const width = rect.width;

            const start = width * 0.22;
            const end = width * 0.88;
            const space = end - start;

            setContainerWidth(width);
            setBeatSlotsSegment({start, end});
            setBeatSpace(space);

        }

        updateSize();

        const observer = new ResizeObserver(updateSize);
        observer.observe(element);

        return () => {
            observer.disconnect();
        };
    }, []);

    function getPositionInSameValueBlock(index: number, values: number[], blockSize: number) {
        const value = values[index];
        if (value === undefined) return 0;

        let streakLength = 0;

        for (let i = index; i >= 0; i--) {
            if (values[i] !== value) {
                break;
            }

            streakLength++;
        }

        return ((streakLength - 1) % blockSize) + 1;
    }

    function isEighthEnd(index: number, values: number[]) {
        return getPositionInSameValueBlock(index, values, 2) === 2;
    }

    function isSixteenthEnd(index: number, values: number[]) {
        const positionInBlock = getPositionInSameValueBlock(index, values, 4);

        return positionInBlock > 1;
    }

    function isThirtySecondEnd(index: number, values: number[]) {
        const positionInBlock = getPositionInSameValueBlock(index, values, 8);

        return positionInBlock > 1;
    }

    function getBeatValueImage(value: number, index: number, values: number[]):NoteImageData {
        switch (value) {
            case 1:
                return {noteSrc: ganzeNote};

            case 1 / 2:
                return {noteSrc: halbeNote};
            case 3 / 4:
                return {noteSrc: halbeNote, dotSrc: dotted}
            case 7 / 8:
                return {noteSrc: halbeNote, dotSrc: doubleDotted}
            case 1 / 4:
                return {noteSrc: viertelNote};
            case 3 / 8:
                return {noteSrc: viertelNote, dotSrc: dotted}
            case 7 / 16:
                return {noteSrc: viertelNote, dotSrc: doubleDotted}
            case 1 / 8:
                return isEighthEnd(index, values)
                    ? smallestValue > 1 / 32 ? {noteSrc: achtelEnd} : {noteSrc: achtelEndLong}
                    : {noteSrc: achtelNote};
            case 3 / 16:
                return {noteSrc: achtelNote, dotSrc: dotted}
            case 7 / 32:
                return {noteSrc: achtelNote, dotSrc: doubleDotted}
            case 1 / 16:
                return isSixteenthEnd(index, values)
                    ? smallestValue > 1/32 ? {noteSrc: sechzehntelNoteEnd } : {noteSrc: sechzehntelNoteEndLong }
                    : {noteSrc: sechzehntelNote };
            case 3 / 32:
                return {noteSrc: sechzehntelNote, dotSrc: dotted}
            case 1 / 32:
                return isThirtySecondEnd(index, values)
                    ? {noteSrc: zweiunddreissigstelNoteEnd}
                    : {noteSrc: zweiunddreissigstelNote};

            default:
                return{noteSrc: ""};
        }
    }

    function getNoteXShift(src: string) {
        switch (src) {
            case achtelEnd:
                return -containerWidth / 22
            case achtelEndLong:
                return -containerWidth * 1 / 16
            case sechzehntelNoteEnd:
                return -containerWidth / 68
            case sechzehntelNoteEndLong:
                return -containerWidth / 41
            case zweiunddreissigstelNoteEnd:
                return -containerWidth / 700
            default:
                return 0
        }
    }

    function getNoteScaleAndPosition(values: number[]) {
        let slotProgress = 0;
        const positions: number[] = values.map((value) => {
            const position = slotProgress;
            const slot = availableSlots * value
            slotProgress += slot
            return position;
        });
        return positions;
    }

    function getNoteLayout(containerHeight: number) {
        if (smallestValue === 0) {
            return {top: 0, height: 0};
        }


        if (smallestValue > 1 / 16) {
            return {top: -containerHeight * 0.08, height: containerHeight * 0.73};
        } else if (smallestValue > 1 / 32) {
            return {top: containerHeight * 0.16, height: containerHeight * 0.48};
        } else {
            return {top: containerHeight * 0.28, height: containerHeight * 0.30};
        }
    }

    return (
        <Box
            ref={containerRef}
            sx={{
                position: "relative",
                width: "100%",
                minWidth: 300,
                height,
            }}
        >
            {/* Taktlinie */}
            <Box
                sx={{
                    position: "absolute",
                    left: "5%",
                    right: "5%",
                    top: height * 0.2,
                }}
                component="img"
                src={beatLine}
            />

            {props.showProgress && <LinearProgress
                variant="determinate"
                value={Math.min(beatValue * 100, 100)}
                sx={{
                    position: "absolute",
                    width: beatSpace,
                    height: 110,
                    left: beatSlotsSegment.start,
                    top: -20,

                    backgroundColor: "rgba(150,150,150,0.15)",

                    "& .MuiLinearProgress-bar": {
                        backgroundColor: "rgba(241,207,114,0.45)",
                    },
                }}
            />
            }

            {/* Noten */}
            <Box
                sx={{
                    position: "relative",
                    height: "100%",
                    zIndex: 1,
                }}
            >
                {containerWidth > 0 && props.beatValues.map((beat, index: number) => {
                    const noteInfo = getBeatValueImage(beat, index, props.beatValues);

                    if (!noteInfo.noteSrc) return null;
                    const endShift = getNoteXShift(noteInfo.noteSrc)

                    return (
                        <Box
                            key={`${beat}-${index}`}
                            sx={{
                                position: "absolute",
                                top: noteLayout.top,
                                left: (slotsToCords[cordsForNotes[index]!] ?? 0) + endShift,
                                height: noteLayout.height,
                            }}
                        >

                        <Box
                            component="img"
                            src={noteInfo.noteSrc}
                            sx={{
                                height: "100%",
                                objectFit: "contain",
                            }}
                        />
                        {noteInfo.dotSrc && (
                            <Box
                                component="img"
                                src={noteInfo.dotSrc}
                                sx={{
                                    position: "absolute",
                                    height: "100%",
                                    left: noteLayout.height * 0.35,
                                }}
                            >
                            </Box>
                        )}

                    </Box>
                    )
                })}
            </Box>
        </Box>
    );
}

export default memo(BeatlineWithNotes);

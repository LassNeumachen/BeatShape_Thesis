# BeatShape Paper.js Prototype

Erster Prototyp für BeatShape. Das Projekt wurde gebaut, um das Konzept zu testen und zu pruefen, ob die visuelle Umsetzung mit Paper.js funktioniert.

## Starten

Das Projekt besteht nur aus einer HTML-Datei. Paper.js und Tone.js werden ueber ein CDN geladen, deshalb wird eine Internetverbindung benötigt.

Voraussetzungen:

- Python
- Internetverbindung

1. Im Projektordner einen lokalen Server starten:

   ```bash
   python -m http.server 8000
   ```

2. Im Browser oeffnen:

   ```text
   http://localhost:8000
   ```

3. Auf `Start` klicken, damit der Browser die Audioausgabe freigibt.

## Dateien

- `index.html`: Prototyp mit Paper.js-Zeichenflaeche, Animation und Tone.js-Sound.

export type CustomShapeInformation = {
    coordinates: [number, number][],
    radius: number,
}

export function calculateShapePoints(notesValues: number[] ) {
    return buildPolygonFromLenghts(notesValues);
}

function buildPolygonFromLenghts(notesValues: number[]): CustomShapeInformation | null {
    const total = notesValues.reduce((total, current) => total + current, 0);
    if ( total <= 0){
        console.log("Summe müsste Positiv sein: ", total);
        return null;
    }

    const r = findRadius(notesValues);
    if(!r){
        console.log("r ist nischt", r)
        return null;
    }

    const centralAngles = notesValues.map(
        (l) => 2 * Math.asin(l / (2 * r))
    );

    const circleAngles = [0];
    let current = 0;

    for (const angle of centralAngles) {
        current += angle;
        circleAngles.push(current);
    }

    const points: [number, number][] = circleAngles.map((t) => [
        r * Math.cos(t) * 400,
        r * Math.sin(t) * 400,
    ]);
    return {coordinates: points, radius: r};
}

function findRadius(notesValues: number[]) {
    const tolerance = 1e-12;
    const maxIteration = 200;

    const total = 1;
    const lMax = Math.max(...notesValues);

    if (lMax >= 1 / 2) {
        console.log("Es kann kein Polygon mit einer Seite geben, die >= 1/2 der Gesamtlänge ist");
        return null;
    }

    let lo = lMax / 2 + 1e-15;
    let hi = Math.max(total, 1.0);

    while (angleSumError(hi, notesValues) > 0) {
        hi *= 2;
    }

    for (let i = 0; i < maxIteration; i++) {
        const mid = (lo + hi) / 2;
        const value = angleSumError(mid, notesValues);

        if (Math.abs(value) < tolerance) {
            return mid;
        }

        if (value > 0) {
            lo = mid;
        } else {
            hi = mid;
        }
    }

    return (lo + hi) / 2;
}

function angleSumError(radius: number, notesValues: number[]) {
    return notesValues.reduce((sum, l) => sum + 2 * Math.asin(l / (2 * radius)), 0) - 2 * Math.PI;
}
import {Box, Button, TextField, Typography} from '@mui/material';
import { useEffect, useRef, useState } from 'react';
import CreateShapeDialog from '../Dialogs/CreateShapeDialog';
import { type BeatShape } from '../types/shapes';
import { createShape, type CreateShapeInput } from '../lib/shapeFactory';
import paper from 'paper';
import {startAudio, testSound, playSound, suspendAudio, resumeAudio} from '../lib/audioEngine';
import type {Sound} from "../types/sounds";
import IconButton from "@mui/material/IconButton";
import SoundToggleButton from "../components/MuteButtonComponent";
import StartStopButton from "../components/StopPlayButtonComponent";
import MusicNoteIcon from '@mui/icons-material/MusicNote';
import Slider from "@mui/material/Slider";
import {checkTriggerCrossing} from "../lib/helper/TriggerHelper";
import {calculateShapePoints} from "../lib/helper/shapeCalculator";

type StageProps = {
    onStageClick?: (x: number, y: number) => void;
};

type RuntimeShape = {
    id: string;
    path: paper.Path;
    marker: paper.Path.Circle;
    startOffset: number;
    offset: number;
    loopDuration: number;
    triggerOffsets: number[];
    sound: Sound;
};



export default function Stage({ onStageClick }: StageProps) {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const paperScopeRef = useRef<paper.PaperScope | null>(null);

    const [screenCoordinates, setScreenCoordinates] = useState({ x: 0, y: 0 });
    const [canvasCoordinates, setCanvasCoordinates] = useState({ x: 0, y: 0 });

    const [coordinates, setCoordinates] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [mousePosition, setMousePosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
    const [manageDialog, setManageDialog] = useState(false);
    const [shapes, setShapes] = useState<BeatShape[]>([]);
    const runtimeShapesRef = useRef<RuntimeShape[]>([]);
    const [bpm, setBpm] = useState<number>(120)
    const [sekToEncircle, setSekToEncircle] = useState<number>(2)
    const [play, setPlay] = useState<boolean>(true);
    const [muted, setMuted] = useState<boolean>(false);

    const [editingShape, setEditingShape] = useState<BeatShape | null>(null);
    const [draggingShapeId, setDraggingShapeId] = useState<string | null>(null);
    const dragOffsetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
    const wasDraggingRef = useRef(false);

    startAudio();

    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        scope.activate();
        scope.project.clear();

        const runtimeShapes = shapes.map((shape) => {
            let path: paper.Path;

            if (shape.type === 'polygon') {
                path = new scope.Path.RegularPolygon({
                    center: new scope.Point(shape.x, shape.y),
                    sides: shape.corners,
                    radius: shape.size,
                    fillColor: shape.fillColor,
                    sound: shape.sound,
                });
            } else if (shape.type === 'circle') {
                path = new scope.Path.Circle({
                    center: new scope.Point(shape.x, shape.y),
                    radius: shape.radius,
                    fillColor: shape.fillColor,
                    sound: shape.sound,
                });
            } else {
                path = new scope.Path({
                    segments: shape.cornerPoints,
                    closed: true,
                    fillColor: shape.fillColor,
                    sound: shape.sound,
                });
            }
            path.data.shapeId = shape.id;

            if(shape.rotation !== undefined) {
                path.rotation = shape.rotation
            }
            const phaseOffset = ((shape.rotation ?? 0) / 360) * path.length;
            const triggerOffsets =
                shape.type === 'circle'
                    ? [0]
                    : path.segments
                        .map((segment) => path.getOffsetOf(segment.point))
                        .filter((offset): offset is number => offset !== null);


            console.log(phaseOffset);
            console.log(path.length)
            const startOffset = phaseOffset % path.length;
            console.log(startOffset);
            // const triggerOffsets = shape.type === 'circle' ? [0] : path.segments.map((segment) => path.getOffsetOf(segment.point)).filter((offset): offset is number => offset !== null);

            const marker = new scope.Path.Circle({
                center: path.getPointAt(startOffset) ?? path.position,
                radius: 10,
                fillColor: 'white',
            });

            return {
                id: shape.id,
                path,
                marker,
                offset: startOffset,
                startOffset,
                loopDuration: sekToEncircle,
                triggerOffsets,
                sound: shape.sound,
            };

        });

        runtimeShapesRef.current = runtimeShapes;
    }, [shapes, sekToEncircle]);




    useEffect(() => {
        if (!canvasRef.current) return;

        const scope = new paper.PaperScope();
        scope.setup(canvasRef.current);
        paperScopeRef.current = scope;

        return () => {
            scope.project.clear();
        };
    }, []);


    useEffect(() => {
        const scope = paperScopeRef.current;
        if (!scope) return;

        if (!play) {
            scope.view.onFrame = null;
            return;
        }

        scope.view.onFrame = (event: { delta: number }) => {
            for (const runtime of runtimeShapesRef.current) {
                const oldOffset = runtime.offset;
                const speed = runtime.path.length / runtime.loopDuration;
                const newOffset = (runtime.offset + speed * event.delta) % runtime.path.length;


                const triggered = checkTriggerCrossing(
                    runtime.triggerOffsets,
                    oldOffset,
                    newOffset,
                    runtime.path.length
                );

                runtime.offset = newOffset;

                runtime.marker.position =
                    runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;
                if (triggered && !muted) {
                    playSound(runtime.id, runtime.sound);
                }
            }
        };

        return () => {
            scope.view.onFrame = null;
        };
    }, [play, muted]);

    function resetAllRuntimeShapes() {
        for (const runtime of runtimeShapesRef.current) {
            runtime.offset = runtime.startOffset;
            runtime.marker.position =
                runtime.path.getPointAt(runtime.startOffset) ?? runtime.path.position;
        }
    }


    function syncRuntimeOffsetsToShapes() {
        setShapes((prevShapes) =>
            prevShapes.map((shape) => {
                const runtime = runtimeShapesRef.current.find((item) => item.id === shape.id);
                if (!runtime) return shape;

                return {
                    ...shape,
                    offset: runtime.offset,
                    lastOffset: runtime.offset,
                };
            })
        );
    }


    function handleClick(event: React.MouseEvent<HTMLDivElement>) {
        if (wasDraggingRef.current) {
            wasDraggingRef.current = false;
            return;
        }

        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() !== 'canvas' || target.id !== 'MainCanvas') {
            return;
        }

        const scope = paperScopeRef.current;
        if (!scope || !canvasRef.current) return;

        const rect = canvasRef.current.getBoundingClientRect();
        const canvasX = event.clientX - rect.left;
        const canvasY = event.clientY - rect.top;

        onStageClick?.(canvasX, canvasY);

        const hitResult = scope.project.hitTest(new scope.Point(canvasX, canvasY), {
            fill: true,
            stroke: true,
            tolerance: 8,
        });

        const hitShapeId = hitResult?.item?.data?.shapeId;

        resetAllRuntimeShapes();
        syncRuntimeOffsetsToShapes();

        if (hitShapeId) {
            const foundShape = shapes.find((shape) => shape.id === hitShapeId) ?? null;
            setEditingShape(foundShape);

            if (foundShape) {
                setCoordinates({ x: foundShape.x, y: foundShape.y });
            }
        } else {
            setEditingShape(null);
            setCoordinates({ x: canvasX, y: canvasY });
        }

        setManageDialog(true);
    }



    function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
        setMousePosition({
            x: event.clientX,
            y: event.clientY,
        });

        if (!draggingShapeId) return;
        wasDraggingRef.current = true;

        const point = getCanvasPoint(event);
        if (!point) return;

        const runtime = runtimeShapesRef.current.find((item) => item.id === draggingShapeId);
        if (!runtime) return;

        const newPosition = new paper.Point(
            point.x + dragOffsetRef.current.x,
            point.y + dragOffsetRef.current.y
        );

        runtime.path.position = newPosition;
        runtime.marker.position =
            runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;
    }


    function handleCloseDialog() {
        setManageDialog(false);
        setEditingShape(null);
    }

    function onSetMuted() {
        setMuted((prev) => !prev);
    }

    function onStartStop(){
        setPlay((prev) => !prev)
    }

    function setNewSpeed(speed: number) {
        setBpm(speed);
        setSekToEncircle(4-speed/60)
    }

    function getCanvasPoint(event: React.MouseEvent<HTMLDivElement>) {
        if (!canvasRef.current || !paperScopeRef.current) return null;

        const rect = canvasRef.current.getBoundingClientRect();
        return new paperScopeRef.current.Point(
            event.clientX - rect.left,
            event.clientY - rect.top
        );
    }

    function handleMouseDown(event: React.MouseEvent<HTMLDivElement>) {
        wasDraggingRef.current = false;
        const target = event.target as HTMLElement;

        if (target.tagName.toLowerCase() !== 'canvas' || target.id !== 'MainCanvas') {
            return;
        }

        const scope = paperScopeRef.current;
        if (!scope) return;

        const point = getCanvasPoint(event);
        if (!point) return;

        const hitResult = scope.project.hitTest(point, {
            fill: true,
            stroke: true,
            tolerance: 8,
        });

        const hitShapeId = hitResult?.item?.data?.shapeId;

        if (!hitShapeId) {
            setDraggingShapeId(null);
            return;
        }

        const runtime = runtimeShapesRef.current.find((item) => item.id === hitShapeId);
        if (!runtime) return;

        setDraggingShapeId(hitShapeId);

        dragOffsetRef.current = {
            x: runtime.path.position.x - point.x,
            y: runtime.path.position.y - point.y,
        };
    }

    function handleMouseUp() {
        if (!draggingShapeId) return;

        const runtime = runtimeShapesRef.current.find((item) => item.id === draggingShapeId);
        if (!runtime) {
            setDraggingShapeId(null);
            return;
        }

        setShapes((prev) =>
            prev.map((shape) => {
                if (shape.id !== draggingShapeId) return shape;

                if (shape.type === 'custom') {
                    const movedSegments = runtime.path.segments.map((segment) => [
                        segment.point.x,
                        segment.point.y,
                    ] as [number, number]);

                    return {
                        ...shape,
                        x: runtime.path.position.x,
                        y: runtime.path.position.y,
                        cornerPoints: movedSegments,
                    };
                }

                return {
                    ...shape,
                    x: runtime.path.position.x,
                    y: runtime.path.position.y,
                };
            })
        );

        setDraggingShapeId(null);
    }

    return (
    <Box
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onClick={handleClick}
        onMouseMove={handleMouseMove}
        sx={{
            width: '100vw',
            height: '100vh',
            backgroundColor: 'rgb(43,43,43)',
            position: 'relative',
            overflow: 'hidden',
        }}
    >
        <canvas
            ref={canvasRef}
            id="MainCanvas"
            width={window.innerWidth}
            height={window.innerHeight}
            style={{
                position: 'absolute',
                inset: 0,
                width: '100%',
                height: '100%',
                display: 'block',
                zIndex: 0,
            }}
        />

        <Box
            sx={{
                position: 'absolute',
                top: 16,
                left: 16,
                right: 16,
                zIndex: 10,
                display: 'flex',
                alignItems: 'center',
                gap: 2,
                flexWrap: 'wrap',
                px: 2,
                py: 1.5,
                borderRadius: 5,
                backgroundColor: 'rgba(255,255,255,0.65)',
                boxShadow: 3,
                backdropFilter: 'blur(8px)',
            }}
        >

            <Typography>
                {coordinates.x} {coordinates.y}
            </Typography>

            <StartStopButton setRunning={onStartStop} running={play} />

            <SoundToggleButton
                muted={muted}
                setMuted={onSetMuted}
            />

            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                <Slider
                    value={bpm}
                    onChange={(_, value) => setNewSpeed(value as number)}
                    min={80}
                    max={160}
                    sx={{
                        width: 150,
                        color: "#f50b0b",
                        "& .MuiSlider-thumb": {
                            backgroundColor: "#ffffff",
                        },
                        "& .MuiSlider-track": {
                            border: "none",
                        },
                        "& .MuiSlider-rail": {
                            opacity: 0.3,
                            backgroundColor: "#ffffff",
                        },
                    }}
                />
                <Typography sx={{ minWidth: 70 }}>
                    {bpm} BPM
                </Typography>
            </Box>

            <IconButton
                onClick={async () => {
                    await startAudio();
                    testSound();
                }}
            >
                <MusicNoteIcon sx={{ fontSize: 40 }} />
            </IconButton>

            <Button
                onClick={() => {
                    calculateShapePoints([1/4, 1/16, 1/4, 1/8, 1/16, 1/4, 1/4, 1/8])
                }}
            >
                Calculate Test
            </Button>
        </Box>


        {/*<Box*/}
        {/*                sx={{*/}
        {/*                    position: 'fixed',*/}
        {/*                    left: manageDialog ? coordinates.x : mousePosition.x,*/}
        {/*                    top: manageDialog ? coordinates.y : mousePosition.y,*/}
        {/*                    transform: 'translate(-50%, -50%)',*/}
        {/*                    width: 44,*/}
        {/*                    height: 44,*/}
        {/*                    borderRadius: '50%',*/}
        {/*                    backgroundColor: 'rgba(255,255,255,0.2)',*/}
        {/*                    display: 'flex',*/}
        {/*                    alignItems: 'center',*/}
        {/*                    justifyContent: 'center',*/}
        {/*                    pointerEvents: 'none',*/}
        {/*                    zIndex: 20,*/}
        {/*                }}*/}
        {/*            >*/}
        {/*                /!*<Box*!/*/}
        {/*                /!*    component="span"*!/*/}
        {/*                /!*    sx={{*!/*/}
        {/*                /!*        fontSize: 24,*!/*/}
        {/*                /!*        lineHeight: 1,*!/*/}
        {/*                /!*        display: 'block',*!/*/}
        {/*                /!*        transform: 'translateY(2px)',*!/*/}
        {/*                /!*    }}*!/*/}
        {/*                /!*>*!/*/}
        {/*                /!*    +*!/*/}
        {/*                /!*</Box>*!/*/}
        {/*            </Box>*/}

                    {/*{!manageDialog && (*/}
                    {/*    <Box*/}
                    {/*        sx={{*/}
                    {/*            position: 'fixed',*/}
                    {/*            left: mousePosition.x + 30,*/}
                    {/*            top: mousePosition.y,*/}
                    {/*            transform: 'translateY(-50%)',*/}
                    {/*            pointerEvents: 'none',*/}
                    {/*            zIndex: 20,*/}
                    {/*        }}*/}
                    {/*    >*/}
                    {/*        <Typography sx={{ fontSize: 14 }}>*/}
                    {/*            Shape platzieren*/}
                    {/*        </Typography>*/}
                    {/*    </Box>*/}
                    {/*)}*/}

        <CreateShapeDialog
            open={manageDialog}
            onClose={handleCloseDialog}
            onChangeShape={resetAllRuntimeShapes}
            onCreateShape={(input: CreateShapeInput) => {
                if (editingShape) {
                    setShapes((prev) =>
                        prev.map((shape) =>
                            shape.id === editingShape.id
                                ? { ...createShape(input), id: editingShape.id }
                                : shape
                        )
                    );
                    setEditingShape(null);
                } else {
                    setShapes((prev) => [...prev, createShape(input)]);
                }
            }}
            editingShape={editingShape}
            x={editingShape ? editingShape.x : coordinates.x}
            y={editingShape ? editingShape.y : coordinates.y}
            bpm={sekToEncircle}
            previewStartPoint={0}
        />
    </Box>
);
}

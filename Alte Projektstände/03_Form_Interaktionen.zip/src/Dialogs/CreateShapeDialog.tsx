import {
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Button,
    Typography,
    Box,
    Grid,
} from '@mui/material';
import {useEffect, useRef, useState} from "react";
import paper from 'paper'
import type {CreateShapeInput} from "../lib/shapeFactory";
import type {BeatShape, ShapeType} from "../types/shapes";
import {ShapeCard} from "../components/ShapeCard";
import Slider from "@mui/material/Slider";
import {type Sound, type SoundType, soundTypes} from "../types/sounds";
import {SoundComponent} from "../components/SoundComponent";
import {playSound} from "../lib/audioEngine";
import {checkTriggerCrossing} from "../lib/helper/TriggerHelper";
import {calculateShapePoints} from "../lib/helper/shapeCalculator";
import ShapeEditorDialog from "./ShapeEditor";


type CreateShapeDialogProps = {
    open: boolean;
    x: number;
    y: number;
    bpm: number;
    previewStartPoint: number;
    onClose: () => void;
    onCreateShape: (input: CreateShapeInput) => void;
    onChangeShape: () => void;
    editingShape: BeatShape | null;
};

export type ShapeKey = {
    type: ShapeType,
    corners: number,
    value: number[],
    cornerPoints: [number, number][],
    customRadius?: number,
}

type PreviewRuntimeShape = {
    path: paper.Path;
    marker: paper.Path.Circle;
    offset: number;
    startOffset: number;
    loopDuration: number;
    triggerOffsets: number[];
    sound: Sound;
};

const defaultColor = '#2563eb';
const defaultSound: Sound = {soundType: "kickDrum", note: 'C1', duration: '8n', volume: 0};

const defaultShape: ShapeKey = {
    corners: 4,
    type: 'polygon',
    value: [1 / 4, 1 / 4, 1 / 4, 1 / 4],
    cornerPoints: [],
};

const initialShapeOptions: ShapeKey[] = [
    {type: 'circle', corners: 4, value: [1], cornerPoints: []},
    {type: 'polygon', corners: 2, value: [1 / 2, 1 / 2], cornerPoints: []},
    {type: 'polygon', corners: 3, value: [1 / 3, 1 / 3, 1 / 3], cornerPoints: []},
    {type: 'polygon', corners: 4, value: [1 / 4, 1 / 4, 1 / 4, 1 / 4], cornerPoints: []},
    {type: 'polygon', corners: 8, value: [1 / 8, 1 / 8, 1 / 8, 1 / 8, 1 / 8, 1 / 8, 1 / 8, 1 / 8], cornerPoints: []},
    {
        type: 'polygon',
        corners: 12,
        value: [1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12, 1 / 12],
        cornerPoints: []
    },
    {
        type: 'polygon',
        corners: 16,
        value: [1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16, 1 / 16],
        cornerPoints: []
    },
];

export default function CreateShapeDialog({
                                              open,
                                              x,
                                              y,
                                              bpm,
                                              previewStartPoint,
                                              onClose,
                                              onCreateShape,
                                              onChangeShape,
                                              editingShape
                                          }: CreateShapeDialogProps) {
    const [selectedShape, setSelectedShape] = useState<ShapeKey>(defaultShape)
    const [volume, setVolume] = useState(0)
    const [rotation, setRotation] = useState(0)
    const [color, setColor] = useState<string>(defaultColor);
    const [sound, setSound] = useState<Sound>(defaultSound)
    const colors = ['#2563eb', '#ef4444', '#10b981', '#f59e0b', '#111827'];

    const previewCanvas = useRef<HTMLCanvasElement | null>(null);
    const previewScopeRef = useRef<paper.PaperScope | null>(null);
    const previewRuntimeRef = useRef<PreviewRuntimeShape | null>(null);

    const [shapeOptions, setShapeOptions] = useState<ShapeKey[]>(initialShapeOptions);
    const [openShapeEditor, setOpenShapeEditor] = useState<boolean>(false);

    useEffect(() => {
        if (editingShape !== null) {
            if (editingShape.type === 'polygon') {
                setSelectedShape({
                    type: editingShape.type,
                    corners: editingShape.corners,
                    value: editingShape.value,
                    cornerPoints: [],
                });
            } else if (editingShape.type === 'circle') {
                setSelectedShape({
                    type: editingShape.type,
                    corners: 0,
                    value: editingShape.value,
                    cornerPoints: [],
                });
            } else if (editingShape.type === 'custom') {
                setSelectedShape({
                    type: editingShape.type,
                    corners: editingShape.cornerPoints!.length,
                    value: editingShape.value,
                    cornerPoints: editingShape.cornerPoints!,
                });
            }

            setSound(editingShape.sound);
            setVolume(editingShape?.sound?.volume);
            setRotation(editingShape.rotation);
            setColor(editingShape.fillColor);
        } else {
            reset();
        }
    }, [editingShape]);


    useEffect(() => {
        if (!previewCanvas.current) return;

        if (open) {
            if (!previewScopeRef.current) {
                const scope = new paper.PaperScope();
                scope.setup(previewCanvas.current);
                scope.activate();
                previewScopeRef.current = scope;
            }

            const timeout = window.setTimeout(() => {
                onChangeShape();
            }, 10);

            // return () => {
            //     window.clearTimeout(timeout);
            // };
        } else {
            reset()
            if (previewScopeRef.current) {
                previewScopeRef.current.view.onFrame = null;
                previewScopeRef.current.project.clear();
                previewScopeRef.current = null;
            }
            previewRuntimeRef.current = null;
        }
    }, [open]);


    function getSizeFromVolume() {
        return volume * 2.5 + 90;
    }

    const handleCreate = () => {
        let input: CreateShapeInput;

        if (selectedShape.type === 'circle') {
            input = {
                type: selectedShape.type,
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                radius: getSizeFromVolume(),
                rotation: rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            }
        } else if (selectedShape.type === 'polygon') {
            input = {
                type: selectedShape.type,
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                size: getSizeFromVolume(),
                corners: selectedShape.corners,
                rotation: rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            };
        } else if (selectedShape.type === 'custom') {
            const scaledCustomPoints = scalePoints(selectedShape.cornerPoints, getSizeFromVolume() / 100);
            input = {
                type: selectedShape.type,
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                cornerPoints: translatePoints(scaledCustomPoints, x, y),
                rotation: rotation,
                value: selectedShape.value,
                sound: {
                    ...sound,
                    volume,
                },
            };
        } else {
            // Default
            input = {
                type: 'polygon',
                x,
                y,
                fillColor: color,
                ballColor: 'white',
                offset: 0,
                lastOffset: 0,
                size: getSizeFromVolume(),
                corners: defaultShape.corners,
                rotation: 0,
                value: defaultShape.value,
                sound: {
                    ...defaultSound,
                },
            }
        }

        onCreateShape(input);
    };

    function translatePoints(
        points: [number, number][],
        offsetX: number,
        offsetY: number
    ): [number, number][] {
        return points.map(([px, py]) => [px + offsetX, py + offsetY]);
    }

    function reset() {
        setVolume(0);
        setRotation(0);
        setColor(defaultColor)
        setSound(defaultSound)
        setSelectedShape(defaultShape)
    }

    function onSetSound(soundType: SoundType) {
        setSound((prev) => ({
            ...prev,
            soundType,
        }));
        onChangeShape();
    }

    function scalePoints(
        points: [number, number][],
        scale: number
    ): [number, number][] {
        return points.map(([px, py]) => [px * scale, py * scale]);
    }


    function onSetActiveShape(key: ShapeKey) {
        onChangeShape();
        setSelectedShape(key);
    }

    function onSetRotation(value: number) {
        setRotation(value);
        onChangeShape();
    }

    function onSetVolunme(value: number) {
        setVolume(value);
        onChangeShape();
    }

    function createAndAddNewShape(beatValues: number[]) {
        const newShape = calculateShapePoints(beatValues);

        if (newShape !== null) {
            const newShapeOption: ShapeKey = {
                type: "custom",
                corners: newShape.coordinates.length,
                value: beatValues,
                cornerPoints: newShape.coordinates,
                customRadius: newShape.radius
            }

            const alreadyExists = shapeOptions.some((shapeKey) => shapeKey.type === 'custom' && JSON.stringify(shapeKey.value) === JSON.stringify((newShapeOption.value)))

            if (alreadyExists) {
                // TODO Snackbar benachrichtigung
                return
            } else {
                console.log(shapeOptions.at(-1))
            }
            setShapeOptions((prev) => [
                ...prev,
                {
                    type: "custom",
                    corners: newShape.coordinates.length,
                    value: beatValues,
                    cornerPoints: newShape.coordinates,
                    customRadius: newShape.radius
                },
            ]);
        }

        setOpenShapeEditor(false)
    }


    // ===================================== PREVIEW =====================================
    useEffect(() => {
        if (!open) return;

        const scope = previewScopeRef.current;
        const canvas = previewCanvas.current;

        if (!scope || !canvas) return;

        scope.activate();
        scope.project.clear();

        const center = new scope.Point(canvas.width / 2, canvas.height / 2);

        // const scaledCustomPoints = scalePoints(selectedShape.cornerPoints, getSizeFromVolume() / 100);
        const scaledCustomPoints = selectedShape.cornerPoints;
        const customPreviewPoints = translatePoints(
            scaledCustomPoints,
            canvas.width / 2,
            canvas.height / 2
        );

        let path: paper.Path;

        if (selectedShape.type === "polygon") {
            path = new scope.Path.RegularPolygon({
                center,
                sides: selectedShape.corners,
                radius: getSizeFromVolume(),
                fillColor: color,
            });
        } else if (selectedShape.type === "custom") {
            path = new scope.Path({
                // segments: selectedShape.cornerPoints,
                segments: customPreviewPoints,
                closed: true,
                fillColor: color,
            })
        } else {
            path = new scope.Path.Circle({
                center,
                radius: getSizeFromVolume(),
                fillColor: color,
            });
        }

        path.rotation = rotation;

        const triggerOffsets =
            selectedShape.type === "circle"
                ? [0]
                : path.segments
                    .map((segment) => path.getOffsetOf(segment.point))
                    .filter((offset): offset is number => offset !== null);

        const normalizedProgress = previewStartPoint;
        const phaseOffset = ((rotation ?? 0) / 360) * path.length;
        const startOffset = (normalizedProgress * path.length + phaseOffset) % path.length;

        const marker = new scope.Path.Circle({
            center: path.getPointAt(startOffset) ?? path.position,
            radius: 10,
            fillColor: "white",
        });

        const loopDuration = bpm;

        previewRuntimeRef.current = {
            path,
            marker,
            offset: startOffset,
            startOffset,
            loopDuration,
            triggerOffsets,
            sound: {
                ...sound,
                volume,
            },
        };
    }, [open, selectedShape, volume, rotation, color, sound, bpm, previewStartPoint]);

    useEffect(() => {
        if (!open) return;

        const scope = previewScopeRef.current;
        if (!scope) return;

        scope.activate();

        scope.view.onFrame = (event: { delta: number }) => {
            const runtime = previewRuntimeRef.current;
            if (!runtime) return;

            const oldOffset = runtime.offset < 0 ? runtime.startOffset : runtime.offset;
            const speed = runtime.path.length / runtime.loopDuration;
            const newOffset =
                (runtime.offset + speed * event.delta) % runtime.path.length;

            const triggered = checkTriggerCrossing(
                runtime.triggerOffsets,
                oldOffset,
                newOffset,
                runtime.path.length
            );

            runtime.offset = newOffset;

            runtime.marker.position =
                runtime.path.getPointAt(runtime.offset) ?? runtime.path.position;

            if (triggered) {
                playSound("preview-shape", runtime.sound);
            }
        };

        return () => {
            scope.view.onFrame = null;
        };
    }, [open, bpm]);

    return (
        <Dialog open={open} onClose={onClose} keepMounted PaperProps={{
            sx: {
                width: 1200,
                maxWidth: 'none',
            },
        }}>
            <DialogTitle>Shape erstellen</DialogTitle>
            <DialogContent>
                <Typography>
                    Position: {x}, {y}
                </Typography>
                <Typography>
                    Active Shape: {selectedShape.type} {selectedShape.corners}
                </Typography>

                <Grid container={true}>
                    <Grid size={7} sx={{padding: 1}}>
                        <Box sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            backgroundColor: 'lightgray'
                        }}>
                            <canvas ref={previewCanvas} height={300} width={300}></canvas>
                        </Box>
                    </Grid>
                    <Grid size={5} sx={{padding: 1}}>
                        <Grid container spacing={2}>
                            {shapeOptions.map((shape) => {
                                return (
                                    <ShapeCard
                                        color={color}
                                        key={`${shape.type}-${shape.corners}-${shape.cornerPoints}`}
                                        shape={shape}
                                        activeShape={selectedShape}
                                        setActiveShape={onSetActiveShape}
                                    />
                                );
                            })}
                        </Grid>
                        <Button
                            onClick={() => {
                                setOpenShapeEditor(true)
                            }}
                        >
                            Build New Beatshape
                        </Button>
                    </Grid>
                </Grid>

                {soundTypes.map((soundType) => (
                    <SoundComponent
                        key={soundType}
                        soundType={soundType}
                        volume={volume}
                        activeSound={sound.soundType}
                        setActiveSound={onSetSound}
                    >

                    </SoundComponent>
                ))}


                <Box sx={{display: 'flex', gap: 1}}>
                    {colors.map((colorOption) => (
                        <Box
                            key={colorOption}
                            onClick={() => setColor(colorOption)}
                            sx={{
                                width: 28,
                                height: 28,
                                borderRadius: '50%',
                                backgroundColor: colorOption,
                                cursor: 'pointer',
                                border: color === colorOption ? '2px solid black' : '2px solid transparent',
                            }}
                        />
                    ))}
                </Box>
                {/*<VolumeSlider onChange={onSetVolume}></VolumeSlider>*/}
                <Typography>Size/Volume</Typography>
                <Slider
                    aria-label="Volume/Size"
                    value={volume}
                    defaultValue={0}
                    onChange={(_, value) => onSetVolunme(value)}
                    valueLabelDisplay="auto"
                    min={-20}
                    max={20}
                    sx={{
                        width: 300,
                        color: 'success.main',
                        '& .MuiSlider-thumb': {
                            borderRadius: '1px',
                        },
                    }}
                >
                </Slider>
                <Typography>Rotation/Offset</Typography>
                <Slider
                    value={rotation}
                    onChange={(_, value) => onSetRotation(value as number)}
                    // onChangeCommitted={onChangeShape}
                    defaultValue={0}
                    valueLabelDisplay="auto"
                    // shiftStep={30}
                    step={5}
                    // marks
                    min={-180}
                    max={180}
                    sx={{
                        width: 300,
                        color: 'success.main',
                        '& .MuiSlider-thumb': {
                            borderRadius: '1px',
                        },
                    }}
                />
            </DialogContent>
            <DialogActions>
                <Button sx={{backgroundColor: 'lightblue'}} onClick={() => {
                    handleCreate();
                    onClose();
                }
                }>Erstellen</Button>
                <Button sx={{backgroundColor: 'red'}} onClick={onClose}>Schließen</Button>
            </DialogActions>
            <ShapeEditorDialog
                open={openShapeEditor}
                createCustomShape={createAndAddNewShape}
            />
        </Dialog>
    );
}

import {Box, Button, Dialog, Grid, LinearProgress, Typography} from "@mui/material";
import {useState} from "react";

export type ShapeEditorProps = {
    open: boolean;
    createCustomShape: (beatValues: number[]) => void;
}

const values: number[] = [1,1/2,1/4,1/8,1/16,1/32]

export default function ShapeEditorDialog(props: ShapeEditorProps) {
    const [beatValue,setBeatValue] = useState(0);
    const [beatValues, setBeatValues] = useState<number[]>([]);

    function addBeatValue(value: number) {
        setBeatValue(beatValue + value);
        setBeatValues((prev) => [...prev, value]);
    }

    function reset(){
        setBeatValue(0);
        setBeatValues([]);
    }

    return (
        <Dialog open={props.open}>
            <Box sx={{}}>
                <Typography>
                    {beatValue}
                </Typography>
                <LinearProgress
                    variant="determinate"
                    value={beatValue*100}
                >

                </LinearProgress>
                <Typography variant="body2" color="textSecondary">
                    Taktwert
                </Typography>
                <Grid container spacing={2}>
                    {values.map((value) => {
                        return (
                            <Button
                                key={value}
                                sx={{
                                    color: beatValue + value > 1 ? 'red' : 'blue'
                                }}
                                disabled={beatValue + value > 1}
                                onClick={() => addBeatValue(value)}
                            >
                                {value}
                            </Button>
                        );
                    })}

                </Grid>
                <Button onClick={() => reset()}>
                    Reset
                </Button>

                <Button
                    disabled={beatValue !== 1}
                    onClick={() => {
                        props.createCustomShape(beatValues);
                    }}
                >
                    create
                </Button>
            </Box>
        </Dialog>
    )
}
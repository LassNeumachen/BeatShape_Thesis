import IconButton from "@mui/material/IconButton";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import PauseIcon from '@mui/icons-material/Pause';

export type ToggleButtonProps = {
    setRunning: () => void;
    running: boolean;
};

export default function StartStopButton(props: ToggleButtonProps) {
    return (
        <IconButton
            disableRipple
            onClick={() => props.setRunning()}
            sx={{
                backgroundColor: "transparent",
                "&:hover": { backgroundColor: "transparent" },
            }}
        >
            {props.running ? (
                <PauseIcon sx={{ fontSize: 40 }} />
            ) : (
                <PlayArrowIcon sx={{ fontSize: 40 }} />
            )}
        </IconButton>
    );
}
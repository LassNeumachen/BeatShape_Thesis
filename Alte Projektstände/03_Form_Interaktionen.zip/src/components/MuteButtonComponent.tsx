import { useState } from "react";
import IconButton from "@mui/material/IconButton";
import VolumeOffIcon from "@mui/icons-material/VolumeOff";
import VolumeUpIcon from "@mui/icons-material/VolumeUp";

export type ToggleButtonProps = {
    setMuted: () => void;
    muted: boolean;
}

export default function SoundToggleButton(props: ToggleButtonProps) {

    return (
        <IconButton
            disableRipple
            onClick={() => props.setMuted()}
            sx={{
                backgroundColor: "transparent",
                "&:hover": { backgroundColor: "transparent" },
            }}
        >
            {props.muted ? (
                <VolumeOffIcon sx={{ fontSize: 40 }} />
            ) : (
                <VolumeUpIcon sx={{ fontSize: 40 }} />
            )}
        </IconButton>
    );
}

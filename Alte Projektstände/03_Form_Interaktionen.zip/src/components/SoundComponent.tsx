import type {Sound, SoundType} from "../types/sounds";
import ToggleButton from "@mui/material/ToggleButton";
import {Box, Button, Typography} from "@mui/material";
import {playSound} from "../lib/audioEngine";

export type SoundComponentProps = {
    soundType: SoundType,
    activeSound: SoundType,
    setActiveSound: (key: SoundType) => void,
    volume: number
}

export function SoundComponent(props: SoundComponentProps) {
    const sound : Sound = { soundType: props.soundType, note: 'C1', duration: '8n', volume: props.volume}
    const isSelected = props.soundType === props.activeSound;


    return (
        <ToggleButton value={props.soundType}
        selected={isSelected}
        onChange={() => props.setActiveSound(props.soundType)}>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                <Typography>{props.soundType}</Typography>
                <Box
                    onClick={(event) => {
                        event.stopPropagation();
                        playSound(sound);
                    }}
                    sx={{
                        px: 1,
                        py: 0.5,
                        borderRadius: 1,
                        backgroundColor: 'lightgray',
                        cursor: 'pointer',
                        textAlign: 'center',
                        fontSize: 14,
                    }}
                >
                    Play sound
                </Box>
            </Box>
        </ToggleButton>
    );
}
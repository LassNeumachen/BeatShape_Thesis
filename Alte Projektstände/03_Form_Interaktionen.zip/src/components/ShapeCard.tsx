import {type BoxProps, colors, Paper} from "@mui/material";
import {useEffect, useRef} from 'react';
import paper from 'paper';
import type {ShapeType} from '../types/shapes';
import {AbcTwoTone} from "@mui/icons-material";
import ToggleButton from "@mui/material/ToggleButton";
import type {ShapeKey} from "../Dialogs/CreateShapeDialog";

export type ShapeCardProps = {
    color: string;
    shape: ShapeKey;
    activeShape: ShapeKey
    setActiveShape: (key: ShapeKey) => void;
}

export function ShapeCard(props: ShapeCardProps) {
    const shapeCanvas = useRef<HTMLCanvasElement | null>(null);

    const isSelected =
        props.shape.type === props.activeShape.type &&
        props.shape.corners === props.activeShape.corners &&
        props.shape.cornerPoints === props.activeShape.cornerPoints
    useEffect(() => {
        if (!shapeCanvas.current) return;
        const scope = new paper.PaperScope();
        scope.setup(shapeCanvas.current);
        scope.project.clear();

        const center = new scope.Point(shapeCanvas.current.width / 2, shapeCanvas.current.height / 2);

        let scaledPoints: [number, number][] = [[0, 0]];
        let customCardPoints: [number, number][] = [[0, 0]];
        if (props.shape.type === 'custom') {
            const r = props.shape.customRadius!;
            const targetRadius = 0.078
            const scale = targetRadius / r

            console.log("Der Radius ist", r)

            scaledPoints = scalePoints(props.shape.cornerPoints, scale)
            customCardPoints = translatePoints(
                scaledPoints,
                shapeCanvas.current.width / 2,
                shapeCanvas.current.height / 2
            );

        }
        console.log(customCardPoints)


        if (props.shape.type === 'polygon') {
            new scope.Path.RegularPolygon({
                center,
                sides: props.shape.corners,
                radius: 28,
                fillColor: props.color,
            });
        } else if (props.shape.type === 'circle') {
            new scope.Path.Circle({
                center,
                radius: 28,
                fillColor: props.color,
            });
        } else if (props.shape.type === 'custom') {
            new scope.Path({
                segments: customCardPoints,
                closed: true,
                fillColor: props.color,
            });
        }

        return () => {
            scope.project.clear();
        };

    }, [props.shape.type, props.shape.corners, props.shape.cornerPoints, props.shape.customRadius, props.color]);

    function translatePoints(
        points: [number, number][],
        offsetX: number,
        offsetY: number
    ): [number, number][] {
        return points.map(([px, py]) => [px + offsetX, py + offsetY]);
    }

    function scalePoints(
        points: [number, number][],
        scale: number
    ): [number, number][] {
        return points.map(([px, py]) => [px * scale, py * scale]);
    }

    return (
        <ToggleButton
            value={`${props.shape.type}-${props.shape.corners}`}
            selected={isSelected}
            onChange={() => props.setActiveShape(props.shape)}
        >
            <canvas ref={shapeCanvas} data-role="shapeCard" width={70} height={70}/>
        </ToggleButton>
    );
}
import { createTheme } from '@mui/material/styles';

const theme = createTheme({
    typography: {
        fontFamily: '"Varela Round", sans-serif',
        h1: {
            fontWeight: 400,
        },
        h2: {
            fontWeight: 400,
        },
        button: {
            fontWeight: 400,
            textTransform: 'none',
        },
    },
});

export default theme;
